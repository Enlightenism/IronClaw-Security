from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from threading import RLock
from typing import Any

from app.core.billing import TOKENS_PER_UNIT, BillingRegistry, get_billing_registry, units_required_for_tokens
from app.core.unit_wallet import InsufficientUnitsError, get_unit_wallet_registry


def _utc_now() -> datetime:
    return datetime.now(UTC)


@dataclass(slots=True)
class UsageAuthorization:
    allowed: bool
    owner_key: str
    requested_units: int
    remaining_units_before: int
    remaining_units_after: int
    reason: str
    plan: str | None = None
    package_id: str | None = None
    wallet_balance_before: int | None = None
    wallet_balance_after: int | None = None
    checked_at: datetime = field(default_factory=_utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class UsageConsumptionResult:
    applied: bool
    owner_key: str
    consumed_units: int
    remaining_units: int
    reason: str
    plan: str | None = None
    package_id: str | None = None
    wallet_balance: int | None = None
    consumed_at: datetime = field(default_factory=_utc_now)
    metadata: dict[str, Any] = field(default_factory=dict)


class UsageMeteringService:
    """Enforces prepaid unit consumption against the billing subscription first,
    while mirroring purchased units into the local unit wallet for visibility.
    """

    def __init__(self, *, billing_registry: BillingRegistry | None = None) -> None:
        self._lock = RLock()
        self._billing_registry = billing_registry or get_billing_registry()
        self._wallet_registry = get_unit_wallet_registry()

    def _normalize_owner_key(self, owner_key: str) -> str:
        normalized = owner_key.strip().lower()
        if not normalized:
            raise ValueError("owner_key must not be empty")
        return normalized

    def _get_wallet_balance(self, owner_key: str) -> int:
        wallet = self._wallet_registry.get_wallet(owner_key)
        if wallet is None:
            return 0
        return int(wallet.balance_units)

    def authorize_usage(
        self,
        *,
        owner_key: str,
        units: int,
        install_key_id: str | None = None,
        program: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UsageAuthorization:
        if units <= 0:
            raise ValueError("units must be positive")

        normalized_owner_key = self._normalize_owner_key(owner_key)
        metadata = dict(metadata or {})

        with self._lock:
            if install_key_id is not None:
                if not program:
                    raise ValueError("program is required for install-key usage authorization")
                wallet_balance_before = self._get_wallet_balance(normalized_owner_key)
                allowed = wallet_balance_before >= units
                return UsageAuthorization(
                    allowed=allowed,
                    owner_key=normalized_owner_key,
                    requested_units=units,
                    remaining_units_before=wallet_balance_before,
                    remaining_units_after=max(wallet_balance_before - units, 0),
                    reason="authorized" if allowed else "insufficient_wallet_units",
                    wallet_balance_before=wallet_balance_before,
                    wallet_balance_after=max(wallet_balance_before - units, 0) if allowed else wallet_balance_before,
                    metadata={**metadata, "install_key_id": install_key_id, "program": program},
                )

            subscription = self._billing_registry.get_active_subscription_for_customer(
                normalized_owner_key,
            )
            wallet_balance_before = self._get_wallet_balance(normalized_owner_key)

            if subscription is None:
                return UsageAuthorization(
                    allowed=False,
                    owner_key=normalized_owner_key,
                    requested_units=units,
                    remaining_units_before=0,
                    remaining_units_after=0,
                    reason="no_active_subscription",
                    wallet_balance_before=wallet_balance_before,
                    wallet_balance_after=wallet_balance_before,
                    metadata=metadata,
                )

            remaining_before = subscription.remaining_units
            allowed = self._billing_registry.can_consume(
                customer_id=normalized_owner_key,
                units=units,
            )

            if not allowed:
                return UsageAuthorization(
                    allowed=False,
                    owner_key=normalized_owner_key,
                    requested_units=units,
                    remaining_units_before=remaining_before,
                    remaining_units_after=remaining_before,
                    reason="insufficient_plan_units",
                    plan=subscription.plan,
                    package_id=subscription.subscription_id,
                    wallet_balance_before=wallet_balance_before,
                    wallet_balance_after=wallet_balance_before,
                    metadata=metadata,
                )

            return UsageAuthorization(
                allowed=True,
                owner_key=normalized_owner_key,
                requested_units=units,
                remaining_units_before=remaining_before,
                remaining_units_after=max(remaining_before - units, 0),
                reason="authorized",
                plan=subscription.plan,
                package_id=subscription.subscription_id,
                wallet_balance_before=wallet_balance_before,
                wallet_balance_after=wallet_balance_before,
                metadata=metadata,
            )

    def authorize_token_usage(
        self,
        *,
        owner_key: str,
        token_count: int,
        metadata: dict[str, Any] | None = None,
    ) -> UsageAuthorization:
        if token_count <= 0:
            raise ValueError("token_count must be positive")

        requested_units = units_required_for_tokens(token_count)
        merged_metadata = {
            **dict(metadata or {}),
            "token_count": token_count,
            "tokens_per_unit": TOKENS_PER_UNIT,
            "requested_units": requested_units,
        }
        return self.authorize_usage(
            owner_key=owner_key,
            units=requested_units,
            metadata=merged_metadata,
        )

    def consume_usage(
        self,
        *,
        owner_key: str,
        units: int,
        install_key_id: str | None = None,
        program: str | None = None,
        event_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UsageConsumptionResult:
        if units <= 0:
            raise ValueError("units must be positive")

        normalized_owner_key = self._normalize_owner_key(owner_key)
        metadata = dict(metadata or {})

        with self._lock:
            authorization = self.authorize_usage(
                owner_key=normalized_owner_key,
                units=units,
                install_key_id=install_key_id,
                program=program,
                metadata=metadata,
            )
            if not authorization.allowed:
                return UsageConsumptionResult(
                    applied=False,
                    owner_key=normalized_owner_key,
                    consumed_units=0,
                    remaining_units=authorization.remaining_units_before,
                    reason=authorization.reason,
                    plan=authorization.plan,
                    package_id=authorization.package_id,
                    wallet_balance=authorization.wallet_balance_before,
                    metadata=metadata,
                )

            if install_key_id is not None:
                if not program:
                    raise ValueError("program is required for install-key usage consumption")
                try:
                    wallet, _, _ = self._wallet_registry.debit_units_for_install_key(
                        owner_key=normalized_owner_key,
                        key_id=install_key_id,
                        program=program,
                        units=units,
                        action_type=str(metadata.get("action_name") or "action"),
                        metadata={**metadata, "event_id": event_id},
                    )
                except InsufficientUnitsError:
                    current_balance = self._get_wallet_balance(normalized_owner_key)
                    return UsageConsumptionResult(
                        applied=False,
                        owner_key=normalized_owner_key,
                        consumed_units=0,
                        remaining_units=current_balance,
                        reason="insufficient_wallet_units",
                        wallet_balance=current_balance,
                        metadata=metadata,
                    )

                return UsageConsumptionResult(
                    applied=True,
                    owner_key=normalized_owner_key,
                    consumed_units=units,
                    remaining_units=wallet.balance_units,
                    reason="consumed",
                    wallet_balance=wallet.balance_units,
                    metadata={**metadata, "install_key_id": install_key_id, "program": program, "event_id": event_id},
                )

            subscription = self._billing_registry.record_usage(
                customer_id=normalized_owner_key,
                units=units,
            )

            wallet = self._wallet_registry.debit_units(
                owner_key=normalized_owner_key,
                units=units,
                metadata={
                    "source": "usage_metering",
                    "package_id": subscription.subscription_id,
                    "plan": subscription.plan,
                    **metadata,
                },
            )

            return UsageConsumptionResult(
                applied=True,
                owner_key=normalized_owner_key,
                consumed_units=units,
                remaining_units=subscription.remaining_units,
                reason="consumed",
                plan=subscription.plan,
                package_id=subscription.subscription_id,
                wallet_balance=wallet.balance_units,
                metadata=metadata,
            )

    def consume_token_usage(
        self,
        *,
        owner_key: str,
        token_count: int,
        metadata: dict[str, Any] | None = None,
    ) -> UsageConsumptionResult:
        if token_count <= 0:
            raise ValueError("token_count must be positive")

        required_units = units_required_for_tokens(token_count)
        merged_metadata = {
            **dict(metadata or {}),
            "token_count": token_count,
            "tokens_per_unit": TOKENS_PER_UNIT,
            "requested_units": required_units,
        }
        return self.consume_usage(
            owner_key=owner_key,
            units=required_units,
            metadata=merged_metadata,
        )

    def get_usage_snapshot(self, *, owner_key: str) -> dict[str, Any]:
        normalized_owner_key = self._normalize_owner_key(owner_key)

        with self._lock:
            subscription = self._billing_registry.get_active_subscription_for_customer(
                normalized_owner_key,
            )
            wallet = self._wallet_registry.get_wallet(normalized_owner_key)

            if subscription is None:
                return {
                    "owner_key": normalized_owner_key,
                    "has_active_subscription": False,
                    "plan": None,
                    "package_id": None,
                    "unit_limit": 0,
                    "units_consumed": 0,
                    "remaining_units": 0,
                    "tokens_per_unit": TOKENS_PER_UNIT,
                    "token_coverage_limit": 0,
                    "remaining_token_coverage": 0,
                    "wallet_balance_units": wallet.balance_units if wallet else 0,
                    "checked_at": _utc_now().isoformat().replace("+00:00", "Z"),
                }

            return {
                "owner_key": normalized_owner_key,
                "has_active_subscription": True,
                "plan": subscription.plan,
                "package_id": subscription.subscription_id,
                "unit_limit": subscription.unit_limit,
                "units_consumed": subscription.units_consumed,
                "remaining_units": subscription.remaining_units,
                "tokens_per_unit": subscription.tokens_per_unit,
                "token_coverage_limit": subscription.token_coverage_limit,
                "remaining_token_coverage": subscription.remaining_token_coverage,
                "wallet_balance_units": wallet.balance_units if wallet else 0,
                "checked_at": _utc_now().isoformat().replace("+00:00", "Z"),
            }


_usage_metering_service = UsageMeteringService()


def get_usage_metering_service() -> UsageMeteringService:
    return _usage_metering_service
