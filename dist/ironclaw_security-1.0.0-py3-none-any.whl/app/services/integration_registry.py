from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any, Literal

from app.core.install_key_formats import get_install_key_format_spec, normalize_install_key_program

IntegrationStatus = Literal["planned", "active", "disabled", "deprecated"]
IntegrationType = Literal["native", "adapter", "cli", "remote"]
CapabilityName = Literal[
    "prompt_interception",
    "tool_interception",
    "execution_interception",
    "file_guard",
    "shell_guard",
    "network_guard",
    "git_guard",
    "review_queue",
    "audit_export",
    "policy_sync",
    "telemetry",
    "guard_assist",
]


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass(slots=True)
class IntegrationCapability:
    name: CapabilityName
    enabled: bool = True
    details: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "enabled": self.enabled,
            "details": self.details,
        }


@dataclass(slots=True)
class IntegrationRecord:
    integration_id: str
    name: str
    slug: str
    platform: str
    integration_type: IntegrationType
    status: IntegrationStatus = "planned"
    version: str = "0.1.0"
    command_name: str | None = None
    description: str = ""
    entrypoint: str | None = None
    install_target: str | None = None
    capabilities: list[IntegrationCapability] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    install_key_program: str | None = None
    install_key_family: str | None = None
    install_key_prefix: str | None = None
    install_key_aliases: list[str] = field(default_factory=list)
    shared_install_key_family: bool = False
    created_at: str = field(default_factory=_utc_now)
    updated_at: str = field(default_factory=_utc_now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "integration_id": self.integration_id,
            "name": self.name,
            "slug": self.slug,
            "platform": self.platform,
            "integration_type": self.integration_type,
            "status": self.status,
            "version": self.version,
            "command_name": self.command_name,
            "description": self.description,
            "entrypoint": self.entrypoint,
            "install_target": self.install_target,
            "capabilities": [capability.to_dict() for capability in self.capabilities],
            "metadata": dict(self.metadata),
            "install_key_program": self.install_key_program,
            "install_key_family": self.install_key_family,
            "install_key_prefix": self.install_key_prefix,
            "install_key_aliases": list(self.install_key_aliases),
            "shared_install_key_family": self.shared_install_key_family,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


@dataclass(slots=True)
class IntegrationRegistry:
    items: dict[str, IntegrationRecord] = field(default_factory=dict)
    created_at: str = field(default_factory=_utc_now)
    updated_at: str = field(default_factory=_utc_now)

    def to_dict(self) -> dict[str, Any]:
        records = sorted(self.items.values(), key=lambda item: (item.platform, item.name, item.integration_id))
        return {
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "total": len(records),
            "items": [record.to_dict() for record in records],
        }

    def list_integrations(
        self,
        *,
        status: IntegrationStatus | None = None,
        platform: str | None = None,
        capability: CapabilityName | None = None,
    ) -> list[IntegrationRecord]:
        return list_integrations(
            self,
            status=status,
            platform=platform,
            capability=capability,
        )

    def integration_summary(self) -> dict[str, Any]:
        return summarize_integration_registry(self)


def _hydrate_install_key_metadata(record: IntegrationRecord) -> IntegrationRecord:
    metadata = dict(record.metadata or {})
    candidates: list[str | None] = [
        record.slug,
        record.platform,
        metadata.get("runtime"),
        metadata.get("program"),
        metadata.get("install_key_program"),
        metadata.get("platform"),
    ]

    normalized_program: str | None = None
    for candidate in candidates:
        if candidate is None:
            continue
        program = normalize_install_key_program(str(candidate).strip())
        if program is not None:
            normalized_program = program
            break

    if normalized_program is not None:
        spec = get_install_key_format_spec(normalized_program)
        record.install_key_program = spec.program
        record.install_key_family = spec.family
        record.install_key_prefix = spec.prefix
        record.install_key_aliases = list(dict.fromkeys(spec.platform_aliases))
        record.shared_install_key_family = len(spec.platform_aliases) > 1 or spec.program == "security_guardian"
        metadata["install_key_program"] = spec.program
        metadata["install_key_family"] = spec.family
        metadata["install_key_prefix"] = spec.prefix
        metadata["install_key_aliases"] = list(record.install_key_aliases)
        metadata["shared_install_key_family"] = record.shared_install_key_family
        metadata.setdefault("runtime", spec.program)
        metadata.setdefault("one_command_install", True)
        if spec.command_template:
            metadata.setdefault("command_template", spec.command_template)
        record.metadata = metadata
    else:
        record.install_key_program = None
        record.install_key_family = None
        record.install_key_prefix = None
        record.install_key_aliases = []
        record.shared_install_key_family = False
        record.metadata = metadata

    return record


def initialize_integration_registry() -> IntegrationRegistry:
    registry = IntegrationRegistry()
    for record in default_integrations():
        register_integration(registry, record)
    return registry


def default_integrations() -> list[IntegrationRecord]:
    records = [
        IntegrationRecord(
            integration_id="integration-claude-code",
            name="Claude Code Adapter",
            slug="claude-code",
            platform="claude-code",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install claude-code",
            description="One-command IronClaw protection layer for Claude Code style local agent workflows.",
            entrypoint="app.adapters.claude_code_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Guard user and system prompt flows."),
                IntegrationCapability("tool_interception", True, "Guard tool invocations before execution."),
                IntegrationCapability("execution_interception", True, "Evaluate execution plans and outcomes."),
                IntegrationCapability("review_queue", True, "Hold risky actions for review."),
                IntegrationCapability("telemetry", True, "Publish integration telemetry events."),
                IntegrationCapability(
                    "guard_assist",
                    True,
                    "Provide Guard assistance through local Prompt Guard classification.",
                ),
            ],
            metadata={
                "priority": 1,
                "one_command_install": True,
                "supports_local_runtime": True,
            },
        ),
        IntegrationRecord(
            integration_id="integration-openclaw",
            name="OpenClaw Adapter",
            slug="openclaw",
            platform="openclaw",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install openclaw",
            description="Adapter layer for OpenClaw-style builder and agent runtimes.",
            entrypoint="app.adapters.openclaw_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True),
                IntegrationCapability("tool_interception", True),
                IntegrationCapability("execution_interception", True),
                IntegrationCapability("file_guard", True),
                IntegrationCapability("network_guard", True),
                IntegrationCapability("policy_sync", True),
                IntegrationCapability("telemetry", True),
            ],
            metadata={
                "priority": 2,
                "one_command_install": True,
                "supports_builder_mode": True,
            },
        ),
        IntegrationRecord(
            integration_id="integration-cursor",
            name="Cursor Adapter",
            slug="cursor",
            platform="cursor",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install cursor",
            description="IronClaw adapter for Cursor agent sessions, code execution, and local workspace command guardrails.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Inspect prompts generated by Cursor before they reach the runtime."),
                IntegrationCapability("tool_interception", True, "Guard tool calls and code execution requests before dispatch."),
                IntegrationCapability("execution_interception", True, "Review command execution plans before invoked actions complete."),
                IntegrationCapability("file_guard", True, "Protect workspace file access, writes, and edits."),
                IntegrationCapability("shell_guard", True, "Harden shell execution and subprocess workflows."),
                IntegrationCapability("telemetry", True, "Emit Cursor runtime and guard telemetry."),
            ],
            metadata={
                "priority": 3,
                "one_command_install": True,
                "supports_local_runtime": True,
                "vendor": "Anysphere",
                "runtime": "cursor",
            },
        ),
        IntegrationRecord(
            integration_id="integration-goose",
            name="Goose Adapter",
            slug="goose",
            platform="goose",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install goose",
            description="IronClaw adapter for Goose agent workflows, covering prompt, command, and tool execution risk control in local developer environments.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Review Goose prompt payloads before execution."),
                IntegrationCapability("tool_interception", True, "Guard tool invocations and chained agent tasks."),
                IntegrationCapability("execution_interception", True, "Validate command plans and risk signals before execution."),
                IntegrationCapability("shell_guard", True, "Enforce shell security handling for software automation."),
                IntegrationCapability("review_queue", True, "Queue suspicious or high-risk actions for human review."),
                IntegrationCapability("telemetry", True, "Publish Goose action and policy telemetry."),
            ],
            metadata={
                "priority": 4,
                "one_command_install": True,
                "supports_local_runtime": True,
                "vendor": "Block",
                "runtime": "goose",
            },
        ),
        IntegrationRecord(
            integration_id="integration-gemini-cli",
            name="Gemini CLI Adapter",
            slug="gemini-cli",
            platform="gemini-cli",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install gemini-cli",
            description="IronClaw adapter for Gemini CLI execution sessions, covering prompt review, shell safety, and secure tool invocation policies.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Guard user and system prompts sent to Gemini CLI agents."),
                IntegrationCapability("tool_interception", True, "Intercept and evaluate external tool calls before execution."),
                IntegrationCapability("execution_interception", True, "Validate execution plans and risky command sequences."),
                IntegrationCapability("network_guard", True, "Monitor outbound network interactions and command flows."),
                IntegrationCapability("shell_guard", True, "Protect CLI subprocess usage and shell access."),
                IntegrationCapability("telemetry", True, "Record Gemini CLI session telemetry and policy decisions."),
            ],
            metadata={
                "priority": 5,
                "one_command_install": True,
                "supports_local_runtime": True,
                "vendor": "Google",
                "runtime": "gemini-cli",
            },
        ),
        IntegrationRecord(
            integration_id="integration-copilot",
            name="GitHub Copilot Adapter",
            slug="copilot",
            platform="copilot",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install copilot",
            description="IronClaw adapter for GitHub Copilot and agentic coding workflows, enforcing guardrails around prompt delivery, command execution, and repository actions.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Review Copilot prompt payloads before generation or command dispatch."),
                IntegrationCapability("tool_interception", True, "Guard Copilot tool calls and workspace actions."),
                IntegrationCapability("execution_interception", True, "Evaluate command and patch execution plans before final completion."),
                IntegrationCapability("git_guard", True, "Protect repository operations and patch workflow integrity."),
                IntegrationCapability("review_queue", True, "Queue high-risk repository or command actions for approval."),
                IntegrationCapability("telemetry", True, "Capture Copilot command and prompt telemetry."),
            ],
            metadata={
                "priority": 6,
                "one_command_install": True,
                "supports_local_runtime": True,
                "vendor": "GitHub",
                "runtime": "copilot",
            },
        ),
        IntegrationRecord(
            integration_id="integration-security-guardian",
            name="Security Guardian Skills Package",
            slug="security-guardian",
            platform="security-guardian",
            integration_type="native",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install security-guardian",
            description="Shared IronClaw skills package for security guardian workflows, policy bundles, and security-focused agent capabilities across supported runtimes.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Review security-sensitive prompts before they reach active runtime tooling."),
                IntegrationCapability("tool_interception", True, "Guard skill-triggered tool calls and security automation actions."),
                IntegrationCapability("execution_interception", True, "Evaluate high-risk security commands before they execute."),
                IntegrationCapability("file_guard", True, "Protect security assets, logs, and operational state files."),
                IntegrationCapability("policy_sync", True, "Synchronize policy bundles and security guard profiles."),
                IntegrationCapability("audit_export", True, "Export review and decision data to the audit log."),
                IntegrationCapability("telemetry", True, "Publish shared security skill telemetry."),
            ],
            metadata={
                "priority": 7,
                "one_command_install": True,
                "supports_local_runtime": True,
                "shared_package": True,
                "runtime": "security-guardian",
                "package_family": "skills",
            },
        ),
        IntegrationRecord(
            integration_id="integration-hermes",
            name="Hermes Adapter",
            slug="hermes",
            platform="hermes",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install hermes",
            description="IronClaw adapter for Hermes agent workflows, prompt/interception guarding, and secure local execution review.",
            entrypoint="app.adapters.hermes_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Guard Hermes prompts as they enter the runtime."),
                IntegrationCapability("tool_interception", True, "Review Hermes tool plans and execution requests before dispatch."),
                IntegrationCapability("execution_interception", True, "Evaluate high-risk Hermes command flows and workflow steps."),
                IntegrationCapability("file_guard", True, "Protect workspace file changes and edits during Hermes operations."),
                IntegrationCapability("shell_guard", True, "Guard shell and subprocess execution in Hermes sessions."),
                IntegrationCapability("telemetry", True, "Publish Hermes runtime policy and execution telemetry."),
            ],
            metadata={
                "priority": 8,
                "one_command_install": True,
                "supports_local_runtime": True,
                "vendor": "Hermes",
                "runtime": "hermes",
            },
        ),
        IntegrationRecord(
            integration_id="integration-generic-agent",
            name="Generic Agent Adapter",
            slug="generic-agent",
            platform="generic",
            integration_type="native",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install generic-agent",
            description="Generic integration profile for AI runtimes that can call IronClaw over local APIs.",
            entrypoint="app.adapters.generic_agent_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True),
                IntegrationCapability("tool_interception", True),
                IntegrationCapability("execution_interception", True),
                IntegrationCapability("audit_export", True),
                IntegrationCapability("telemetry", True),
            ],
            metadata={
                "priority": 9,
                "one_command_install": True,
                "transport": "http",
            },
        ),
        IntegrationRecord(
            integration_id="integration-llamafirewall",
            name="LlamaFirewall Adapter",
            slug="llamafirewall",
            platform="llamafirewall",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install llamafirewall",
            description=("IronClaw adapter for Meta's LlamaFirewall open-source guardrail system. Guards prompt submissions, tool calls, and agent actions through the IronClaw policy engine before dispatching to LlamaFirewall's PromptGuard 2 and agent alignment scanning layers."),
            entrypoint="app.adapters.llamafirewall_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Intercept and evaluate prompts before LlamaFirewall scanning."),
                IntegrationCapability("tool_interception", True, "Guard tool calls and agent actions before dispatch."),
                IntegrationCapability("execution_interception", True, "Evaluate agent execution plans prior to LlamaFirewall."),
                IntegrationCapability("review_queue", True, "Hold flagged prompts and tool calls for human review."),
                IntegrationCapability("audit_export", True, "Export LlamaFirewall scan decisions to the audit log."),
                IntegrationCapability("telemetry", True, "Publish LlamaFirewall integration telemetry events."),
            ],
            metadata={
                "priority": 4,
                "one_command_install": True,
                "supports_local_runtime": True,
                "scanner_layers": ["PromptGuard2", "AgentAlignmentCheck", "CodeShield"],
                "vendor": "Meta",
                "framework": "PurpleLlama",
            },
        ),
        IntegrationRecord(
            integration_id="integration-cape",
            name="CAPE Sandbox Adapter",
            slug="cape",
            platform="cape",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install cape",
            description=("IronClaw adapter for the CAPE malware analysis sandbox. Guards sample, URL, and process submissions through the IronClaw policy engine before dispatching to the CAPE analysis API."),
            entrypoint="app.adapters.cape_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("execution_interception", True, "Gate sandbox task submissions before dispatch to CAPE."),
                IntegrationCapability("file_guard", True, "Evaluate sample files before CAPE analysis."),
                IntegrationCapability("network_guard", True, "Guard URL submissions to CAPE sandbox."),
                IntegrationCapability("review_queue", True, "Hold policy-violating submissions for human review."),
                IntegrationCapability("audit_export", True, "Export CAPE sandbox decisions to the audit log."),
                IntegrationCapability("telemetry", True, "Publish CAPE integration telemetry events."),
            ],
            metadata={
                "priority": 5,
                "one_command_install": True,
                "supports_local_runtime": False,
                "runtime": "cape",
                "analysis_mode": "sandbox-guard",
            },
        ),
        IntegrationRecord(
            integration_id="integration-secret-scanner",
            name="Secret Scanner Adapter",
            slug="secret-scanner",
            platform="secret-scanner",
            integration_type="adapter",
            status="planned",
            version="0.1.0",
            command_name="ironclaw install secret-scanner",
            description="IronClaw adapter for scanning prompts, tool calls, and file content for leaked secrets and credentials.",
            entrypoint="app.adapters.secret_scanner_adapter",
            install_target="local",
            capabilities=[
                IntegrationCapability("prompt_interception", True, "Scan prompt text for secrets before dispatch."),
                IntegrationCapability("tool_interception", True, "Scan tool call arguments for secrets."),
                IntegrationCapability("file_guard", True, "Scan file content for leaked credentials."),
                IntegrationCapability("audit_export", True, "Export secret scan decisions to the audit log."),
                IntegrationCapability("telemetry", True, "Publish secret scanner integration telemetry events."),
            ],
            metadata={
                "priority": 6,
                "one_command_install": True,
                "supports_local_runtime": True,
                "runtime": "secret-scanner",
            },
        ),
    ]
    for record in records:
        _hydrate_install_key_metadata(record)
    return records


def register_integration(
    registry: IntegrationRegistry,
    record: IntegrationRecord,
) -> IntegrationRegistry:
    if not record.integration_id.strip():
        raise ValueError("integration_id is required")
    if not record.slug.strip():
        raise ValueError("slug is required")
    if not record.name.strip():
        raise ValueError("name is required")
    if record.integration_id in registry.items:
        raise ValueError(f"integration already registered: {record.integration_id}")

    now = _utc_now()
    record.created_at = record.created_at or now
    record.updated_at = now
    _hydrate_install_key_metadata(record)
    registry.items[record.integration_id] = record
    registry.updated_at = now
    return registry


def get_integration(
    registry: IntegrationRegistry,
    integration_id: str,
) -> IntegrationRecord | None:
    if integration_id in registry.items:
        return registry.items[integration_id]
    for record in registry.items.values():
        if record.slug == integration_id:
            return record
    return None


def list_integrations(
    registry: IntegrationRegistry,
    *,
    status: IntegrationStatus | None = None,
    platform: str | None = None,
    capability: CapabilityName | None = None,
) -> list[IntegrationRecord]:
    records = list(registry.items.values())

    if status is not None:
        records = [record for record in records if record.status == status]

    if platform is not None:
        normalized_platform = platform.strip().lower()
        records = [record for record in records if record.platform.strip().lower() == normalized_platform]

    if capability is not None:
        records = [record for record in records if any(item.name == capability and item.enabled for item in record.capabilities)]

    return sorted(records, key=lambda item: (item.platform, item.name, item.integration_id))


def update_integration_status(
    registry: IntegrationRegistry,
    integration_id: str,
    status: IntegrationStatus,
) -> IntegrationRecord:
    record = registry.items.get(integration_id)
    if record is None:
        raise KeyError(f"unknown integration_id: {integration_id}")

    now = _utc_now()
    record.status = status
    record.updated_at = now
    registry.updated_at = now
    return record


def summarize_integration_registry(registry: IntegrationRegistry) -> dict[str, Any]:
    records = list_integrations(registry)

    by_status: dict[str, int] = {}
    by_platform: dict[str, int] = {}
    capability_counts: dict[str, int] = {}

    for record in records:
        by_status[record.status] = by_status.get(record.status, 0) + 1
        by_platform[record.platform] = by_platform.get(record.platform, 0) + 1

        for capability in record.capabilities:
            if capability.enabled:
                capability_counts[capability.name] = capability_counts.get(capability.name, 0) + 1

    return {
        "created_at": registry.created_at,
        "updated_at": registry.updated_at,
        "total_integrations": len(records),
        "active_integrations": by_status.get("active", 0),
        "planned_integrations": by_status.get("planned", 0),
        "disabled_integrations": by_status.get("disabled", 0),
        "deprecated_integrations": by_status.get("deprecated", 0),
        "platforms": by_platform,
        "capabilities": capability_counts,
        "one_command_ready_targets": [record.slug for record in records if record.command_name],
    }


_REGISTRY: IntegrationRegistry | None = None


def get_integration_registry() -> IntegrationRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = initialize_integration_registry()
    return _REGISTRY
