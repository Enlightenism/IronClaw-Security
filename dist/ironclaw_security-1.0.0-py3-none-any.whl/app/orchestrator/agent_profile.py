from __future__ import annotations

from dataclasses import asdict, dataclass, field
import logging
from typing import Any, Literal

from app.orchestrator.agent_registry import AgentDescriptor, ProtectedAction

AgentRole = Literal[
    "file_guardian",
    "security_sentinel",
    "execution_watcher",
    "integration_monitor",
    "documentation_observer",
]


AutonomyLevel = Literal[
    "observe_only",
    "review_before_action",
    "restricted_execution",
    "isolated_quarantine_only",
]


EscalationMode = Literal[
    "none",
    "operator_review",
    "security_review",
    "automatic_quarantine",
]


ProfileFocus = Literal[
    "code_integrity",
    "execution_safety",
    "network_boundary",
    "integration_control",
    "documentation_integrity",
]


def _get_logger() -> logging.Logger:
    try:
        from app.core.logging import get_logger  # noqa: PLC0415

        return get_logger("ironclaw.agent_profile")
    except Exception:  # noqa: BLE001
        return logging.getLogger("ironclaw.agent_profile")


_logger: logging.Logger = _get_logger()


# ---------------------------------------------------------------------------
# Module-level re-export so tests can patch
# 'app.orchestrator.agent_profile.get_behavioral_baseline_store'
# ---------------------------------------------------------------------------
try:
    from app.services.behavioral_baseline import (  # noqa: PLC0415
        get_behavioral_baseline_store,
    )
except Exception:  # noqa: BLE001

    def get_behavioral_baseline_store():  # type: ignore[misc]
        raise RuntimeError("behavioral_baseline service is not available")


@dataclass
class AgentProfile:
    agent_id: str
    file_path: str
    role: AgentRole
    autonomy_level: AutonomyLevel
    escalation_mode: EscalationMode
    primary_focus: ProfileFocus
    system_prompt: str
    protected_actions: list[ProtectedAction] = field(default_factory=list)
    risk_tags: list[str] = field(default_factory=list)
    owner_scope: str = "page_of_code"
    can_propose_changes: bool = True
    can_execute_directly: bool = False
    must_use_guard_api: bool = True
    must_log_all_actions: bool = True
    quarantine_on_uncertainty: bool = True
    baseline_status: str = "unknown"
    drift_severity: str = "none"
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _role_for_descriptor(descriptor: AgentDescriptor) -> AgentRole:
    if descriptor.threat_profile == "security_critical":
        return "security_sentinel"
    if descriptor.threat_profile == "execution_capable":
        return "execution_watcher"
    if "api" in descriptor.tags or "integration" in descriptor.tags:
        return "integration_monitor"
    if descriptor.language in {"markdown", "json", "yaml", "html", "css"}:
        return "documentation_observer"
    return "file_guardian"


def _autonomy_for_descriptor(descriptor: AgentDescriptor) -> AutonomyLevel:
    if descriptor.threat_profile == "security_critical":
        return "isolated_quarantine_only"
    if descriptor.threat_profile == "execution_capable":
        return "restricted_execution"
    if descriptor.threat_profile == "sensitive":
        return "review_before_action"
    return "observe_only"


def _escalation_for_descriptor(descriptor: AgentDescriptor) -> EscalationMode:
    if descriptor.threat_profile == "security_critical":
        return "automatic_quarantine"
    if descriptor.threat_profile in {"execution_capable", "sensitive"}:
        return "security_review"
    return "operator_review"


def _focus_for_descriptor(descriptor: AgentDescriptor) -> ProfileFocus:
    if descriptor.threat_profile == "security_critical":
        return "integration_control" if "api" in descriptor.tags else "code_integrity"
    if descriptor.threat_profile == "execution_capable":
        return "execution_safety"
    if "network" in descriptor.tags:
        return "network_boundary"
    if descriptor.language in {"markdown", "json", "yaml", "html", "css"}:
        return "documentation_integrity"
    return "code_integrity"


def _system_prompt_for_descriptor(
    descriptor: AgentDescriptor,
    role: AgentRole,
    autonomy_level: AutonomyLevel,
    focus: ProfileFocus,
) -> str:
    protected = ", ".join(descriptor.protected_actions) if descriptor.protected_actions else "none"
    tags = ", ".join(descriptor.tags) if descriptor.tags else "none"

    return (
        f"You are the IronClaw-assigned security agent for file '{descriptor.relative_path}'. "
        f"Your role is '{role}'. Your autonomy level is '{autonomy_level}'. "
        f"Your primary focus is '{focus}'. "
        f"You protect this file as a dedicated page-of-code security agent. "
        f"You must treat uncertainty as a reason to escalate into guarded review or quarantine. "
        f"Protected actions in your scope: {protected}. "
        f"Risk tags associated with this file: {tags}. "
        f"You must preserve code integrity, avoid unsafe execution, require guarded action routing, "
        f"and maintain auditability for every meaningful action."
    )


def _fetch_baseline_state(agent_id: str) -> tuple[str, str]:
    """Return (baseline_status, drift_severity) for the given agent_id.

    Falls back to ('unknown', 'none') on any failure so the profile build
    is never blocked by baseline availability.
    """
    try:
        store = get_behavioral_baseline_store()
        baseline = store.get_baseline(agent_id)
        if baseline is None:
            return ("learning", "none")

        report = store.compute_drift(agent_id)
        return (baseline.status, report.overall_severity)
    except Exception as exc:  # noqa: BLE001
        _logger.warning(
            "agent_profile_baseline_fetch_failed",
            extra={
                "event": "agent_profile_baseline_fetch_failed",
                "agent_id": agent_id,
                "error": str(exc),
            },
        )
        return ("unknown", "none")


def build_agent_profile(descriptor: AgentDescriptor) -> AgentProfile:
    role = _role_for_descriptor(descriptor)
    autonomy_level = _autonomy_for_descriptor(descriptor)
    escalation_mode = _escalation_for_descriptor(descriptor)
    focus = _focus_for_descriptor(descriptor)

    can_execute_directly = autonomy_level == "restricted_execution" and descriptor.threat_profile != "security_critical"

    baseline_status, drift_severity = _fetch_baseline_state(descriptor.agent_id)

    notes = [
        "This profile is generated by the IronClaw-Security orchestrator.",
        "This agent is assigned to a single file as part of the page-of-code protection model.",
        "Future versions may attach live LLM reasoning, sandbox lanes, and self-upgrade policies.",
    ]

    if descriptor.threat_profile in {"security_critical", "execution_capable"}:
        notes.append("High-sensitivity profile: prefer review or isolation over direct execution.")

    if baseline_status == "learning":
        notes.append("Behavioral baseline is still in learning phase; drift detection will activate once sufficient observations are collected.")
    elif baseline_status == "stale":
        notes.append("Behavioral baseline is stale; recent observations may not reflect the active profile.")
    elif baseline_status == "suspended":
        notes.append("Agent is currently suspended due to critical behavioral drift. Operator review is required before resuming execution.")
    elif baseline_status == "active" and drift_severity in ("high", "critical"):
        notes.append(f"Active behavioral drift detected (severity={drift_severity}). Review agent activity before permitting further execution.")

    return AgentProfile(
        agent_id=descriptor.agent_id,
        file_path=descriptor.relative_path,
        role=role,
        autonomy_level=autonomy_level,
        escalation_mode=escalation_mode,
        primary_focus=focus,
        system_prompt=_system_prompt_for_descriptor(
            descriptor=descriptor,
            role=role,
            autonomy_level=autonomy_level,
            focus=focus,
        ),
        protected_actions=descriptor.protected_actions,
        risk_tags=descriptor.tags,
        owner_scope="page_of_code",
        can_propose_changes=True,
        can_execute_directly=can_execute_directly,
        must_use_guard_api=True,
        must_log_all_actions=True,
        quarantine_on_uncertainty=True,
        baseline_status=baseline_status,
        drift_severity=drift_severity,
        notes=notes,
    )


if __name__ == "__main__":
    from pathlib import Path

    from app.orchestrator.agent_registry import discover_agents

    registry = discover_agents(Path().resolve())
    if not registry.items:
        print({"error": "No agents discovered."})
    else:
        profile = build_agent_profile(registry.items[0])
        print(profile.to_dict())
