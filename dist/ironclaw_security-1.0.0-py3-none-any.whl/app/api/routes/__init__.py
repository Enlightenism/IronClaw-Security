from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.api.routes.billing import router as billing_router
from app.api.routes.install_key_events import router as install_key_events_router
from app.api.routes.unit_ledger import router as unit_ledger_router
from app.api.routes.unit_wallet import router as unit_wallet_router
from app.config import RISK_THRESHOLD_BLOCK_MIN
from app.services import action_decision as action_decision_svc
from app.services import action_guard as action_guard_svc
from app.services import action_policy as action_policy_svc
from app.services import history as history_svc
from app.services import scanner as scanner_svc

router = APIRouter()
router.include_router(unit_wallet_router)
router.include_router(unit_ledger_router)
router.include_router(billing_router)
router.include_router(install_key_events_router)

Verdict = Literal["allow", "block"]


def _normalize_verdict(value: object) -> Verdict:
    return "allow" if value == "allow" else "block"


def _normalize_risk_score(verdict: Verdict, risk_score: int) -> int:
    return max(risk_score, RISK_THRESHOLD_BLOCK_MIN) if verdict == "block" else risk_score


class ScanRequest(BaseModel):
    target_type: str = Field(..., min_length=1)
    target_value: str = Field(..., min_length=1)


class ScanResponse(BaseModel):
    scan_id: str
    verdict: Verdict
    summary: str
    risk_score: int
    matched_patterns: list[str] = Field(default_factory=list)
    risky_files: list[str] = Field(default_factory=list)
    checks_loaded: list[str] = Field(default_factory=list)
    failed_checks: list[str] = Field(default_factory=list)
    review_status: str | None = None
    untrusted: bool | None = None
    quarantine_reason: str | None = None


class HistoryItem(BaseModel):
    scan_id: str
    target_type: str
    target_value: str
    verdict: Verdict
    summary: str
    risk_score: int
    matched_patterns: list[str] = Field(default_factory=list)
    review_status: str | None = None
    untrusted: bool | None = None
    quarantine_reason: str | None = None


def _history_item_response(item: Any) -> HistoryItem:
    verdict = _normalize_verdict(item.verdict)
    return HistoryItem(
        scan_id=item.scan_id,
        target_type=item.targettype,
        target_value=item.targetvalue,
        verdict=verdict,
        summary=item.summary,
        risk_score=_normalize_risk_score(verdict, item.riskscore),
        matched_patterns=list(getattr(item, "matchedpatterns", [])),
        review_status=getattr(item, "reviewstatus", None),
        untrusted=True if verdict == "block" else getattr(item, "untrusted", None),
        quarantine_reason=getattr(item, "quarantinereason", None),
    )


class HistoryListResponse(BaseModel):
    items: list[HistoryItem]


class ReviewRequest(BaseModel):
    action: Literal["approve", "reject"]


class GuardActionRequest(BaseModel):
    action_type: str
    target: str
    content: str
    client_id: str
    session_id: str


class GuardActionResponse(BaseModel):
    action_type: str
    target: str
    content: str
    verdict: Verdict
    should_halt: bool
    should_warn: Literal[False]
    matched_patterns: list[str] = Field(default_factory=list)
    client_id: str
    session_id: str


class GuardPolicyResponse(BaseModel):
    action_type: str
    target: str
    content: str
    policy_mode: Literal["allow", "review", "block"]
    verdict: Verdict
    should_halt: bool
    should_warn: Literal[False]
    client_id: str
    session_id: str


class GuardDecisionResponse(BaseModel):
    action_type: str
    target: str
    content: str
    policy_mode: Literal["allow", "review", "block"]
    verdict: Verdict
    decision_source: Literal["policy", "scan"]
    should_halt: bool
    should_warn: Literal[False]
    matched_patterns: list[str] = Field(default_factory=list)
    client_id: str
    session_id: str


@router.post("/scan/", response_model=ScanResponse)
def scan_target(request: ScanRequest) -> ScanResponse:
    target_type = request.target_type
    target_value = request.target_value

    normalized_value = " ".join(target_value.split())
    if target_type == "text" and not normalized_value:
        raise HTTPException(status_code=400, detail="target_value is empty after normalization")

    if target_type in {"text", "url", "github_repo", "archive"}:
        scan_result = scanner_svc.perform_scan(target_type=target_type, target_value=target_value)
    else:
        raise HTTPException(status_code=400, detail=f"unsupported target_type={target_type}")

    stored = history_svc.append_scan_result(scan_result)
    verdict = _normalize_verdict(stored.verdict)

    return ScanResponse(
        scan_id=stored.scan_id,
        verdict=verdict,
        summary=stored.summary,
        risk_score=_normalize_risk_score(verdict, stored.riskscore),
        matched_patterns=list(getattr(stored, "matchedpatterns", [])),
        risky_files=list(getattr(stored, "riskyfiles", [])),
        checks_loaded=list(getattr(stored, "checksloaded", [])),
        failed_checks=list(getattr(stored, "failedchecks", [])),
        review_status=getattr(stored, "reviewstatus", None),
        untrusted=True if verdict == "block" else getattr(stored, "untrusted", None),
        quarantine_reason=getattr(stored, "quarantinereason", None),
    )


@router.get("/history/", response_model=HistoryListResponse)
def list_history() -> HistoryListResponse:
    items = history_svc.get_history_items()
    return HistoryListResponse(
        items=[_history_item_response(i) for i in items],
    )


@router.get("/history/{scan_id}", response_model=HistoryItem)
def get_history(scan_id: str) -> HistoryItem:
    item = history_svc.get_history_item(scan_id)
    if item is None:
        raise HTTPException(status_code=404, detail="scan_id not found")

    return _history_item_response(item)


@router.post("/history/{scan_id}/review")
def review_history_item(scan_id: str, request: ReviewRequest) -> dict[str, Any]:
    try:
        updated = history_svc.review_scan(scan_id=scan_id, action=request.action)
    except KeyError as err:
        raise HTTPException(status_code=404, detail="scan_id not found") from err

    if updated is None:
        raise HTTPException(status_code=400, detail="review not applicable for this scan")

    history_svc.apply_review_action(updated, request.action)
    return {"status": "ok", "scan_id": scan_id, "action": request.action}


@router.post("/guard/action", response_model=GuardActionResponse)
def guard_action(request: GuardActionRequest) -> GuardActionResponse:
    result = action_guard_svc.evaluate_action(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
    )

    verdict = _normalize_verdict(result.verdict)
    matched_patterns = list(getattr(result, "matchedpatterns", []))

    return GuardActionResponse(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
        verdict=verdict,
        should_halt=verdict == "block",
        should_warn=False,
        matched_patterns=matched_patterns,
        client_id=request.client_id,
        session_id=request.session_id,
    )


@router.post("/guard/action-policy", response_model=GuardPolicyResponse)
def guard_action_policy(request: GuardActionRequest) -> GuardPolicyResponse:
    result = action_policy_svc.evaluate_policy(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
    )

    return GuardPolicyResponse(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
        policy_mode=result.mode,
        verdict=_normalize_verdict(result.verdict),
        should_halt=_normalize_verdict(result.verdict) == "block",
        should_warn=False,
        client_id=request.client_id,
        session_id=request.session_id,
    )


@router.post("/guard/action-decision", response_model=GuardDecisionResponse)
def guard_action_decision(request: GuardActionRequest) -> GuardDecisionResponse:
    result = action_decision_svc.evaluate_action_decision(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
    )

    return GuardDecisionResponse(
        action_type=request.action_type,
        target=request.target,
        content=request.content,
        policy_mode=result.policy_mode,
        verdict=_normalize_verdict(result.verdict),
        decision_source=result.source,
        should_halt=_normalize_verdict(result.verdict) == "block",
        should_warn=False,
        matched_patterns=list(getattr(result, "matchedpatterns", [])),
        client_id=request.client_id,
        session_id=request.session_id,
    )


router.include_router(unit_wallet_router)
router.include_router(unit_ledger_router)
