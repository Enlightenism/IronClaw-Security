from __future__ import annotations

from datetime import UTC, datetime
from functools import lru_cache
from typing import Any

from fastapi import APIRouter, Response, status
from pydantic import BaseModel, Field

from app.core.settings import get_settings
from app.services.prompt_guard import resolve_prompt_guard_path
from app.services.review_queue_service import get_review_queue_summary
from app.services.telemetry import (
    append_telemetry_event,
    read_telemetry_events,
    summarize_telemetry_events,
)

router = APIRouter(prefix="/system", tags=["system"])

SERVICE_NAME = "IronClaw-Security"
SERVICE_VERSION = "1.0.0"
DEGRADED_STATUS = "degraded"
OK_STATUS = "ok"
START_TIME = datetime.now(UTC)

_diagnostics_cache: dict[str, Any] | None = None
_diagnostics_cache_key: str | None = None


class ComponentStatus(BaseModel):
    name: str
    status: str
    details: dict[str, Any] = Field(default_factory=dict)


class LivenessResponse(BaseModel):
    status: str
    service: str
    version: str
    timestamp: str
    uptime_seconds: int


class ReadinessResponse(BaseModel):
    status: str
    service: str
    version: str
    timestamp: str
    uptime_seconds: int
    checks: list[ComponentStatus]


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    timestamp: str
    uptime_seconds: int
    live: bool
    ready: bool
    checks: list[ComponentStatus]


class MetricsSummaryResponse(BaseModel):
    status: str
    service: str
    version: str
    timestamp: str
    uptime_seconds: int
    telemetry_summary: dict[str, Any]
    review_summary: dict[str, Any]
    recent_telemetry_events: list[dict[str, Any]]


class DiagnosticsResponse(BaseModel):
    status: str
    title: str
    summary: str
    service: str
    version: str
    timestamp: str
    uptime_seconds: int
    checks: list[ComponentStatus] = Field(default_factory=list)
    items: list[dict[str, Any]] = Field(default_factory=list)


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def _uptime_seconds() -> int:
    return max(0, int((_utc_now() - START_TIME).total_seconds()))


def _base_response_fields() -> dict[str, Any]:
    return {
        "service": SERVICE_NAME,
        "version": _resolve_version(),
        "timestamp": _iso(_utc_now()),
        "uptime_seconds": _uptime_seconds(),
    }


def _safe_append_telemetry_event(event_name: str, payload: dict[str, Any]) -> None:
    try:
        append_telemetry_event(event_name, payload)
    except Exception:
        pass


def _resolve_version() -> str:
    return SERVICE_VERSION


@lru_cache(maxsize=1)
def _load_action_execute_pipeline_factory():
    from app.dependencies.action_execute import get_action_execute_pipeline

    return get_action_execute_pipeline


def _build_component_status(
    *,
    name: str,
    ok: bool,
    details: dict[str, Any],
) -> ComponentStatus:
    return ComponentStatus(
        name=name,
        status=OK_STATUS if ok else DEGRADED_STATUS,
        details=details,
    )


def _probe_prompt_guard() -> ComponentStatus:
    settings = get_settings()
    model_path = resolve_prompt_guard_path(settings.guard_model_path)
    model_files_present = model_path.is_dir() and (model_path / "config.json").is_file() and (model_path / "model.safetensors").is_file()
    return _build_component_status(
        name="prompt_guard",
        ok=not settings.guard_enabled or model_files_present,
        details={
            "enabled": settings.guard_enabled,
            "model_path": str(model_path),
            "model_files_present": model_files_present,
        },
    )


def _probe_scanner_service() -> ComponentStatus:
    """
    Verify the scanner service can be imported and its scan callable is present.
    """
    scanner_ok = False
    scanner_error: str | None = None
    has_scan_callable = False

    try:
        from app.services.scanner import Scanner

        instance = Scanner()
        has_scan_callable = callable(getattr(instance, "scan", None))
        scanner_ok = has_scan_callable
    except Exception as exc:
        scanner_error = str(exc)

    return _build_component_status(
        name="scanner_service",
        ok=scanner_ok,
        details={
            "initialized": scanner_ok,
            "scan_callable": has_scan_callable,
            **({"error": scanner_error} if scanner_error else {}),
        },
    )


def _probe_history_service() -> ComponentStatus:
    """
    Verify the history service can be imported and its append/read callables are present.
    """
    history_ok = False
    history_error: str | None = None
    has_append = False
    has_read = False

    try:
        from app.services.history import HistoryService

        instance = HistoryService()
        has_append = callable(getattr(instance, "append", None))
        has_read = callable(getattr(instance, "read", None))
        history_ok = has_append and has_read
    except Exception as exc:
        history_error = str(exc)

    return _build_component_status(
        name="history_service",
        ok=history_ok,
        details={
            "initialized": history_ok,
            "append_callable": has_append,
            "read_callable": has_read,
            **({"error": history_error} if history_error else {}),
        },
    )


def _build_readiness_checks() -> list[ComponentStatus]:
    checks: list[ComponentStatus] = []

    pipeline = None
    pipeline_close_available = False
    pipeline_ready = False
    pipeline_error: str | None = None
    try:
        get_action_execute_pipeline = _load_action_execute_pipeline_factory()
        pipeline = get_action_execute_pipeline()
        pipeline_ready = pipeline is not None
        pipeline_close_available = callable(getattr(pipeline, "close", None)) if pipeline is not None else False
    except Exception as exc:
        pipeline_error = str(exc)

    checks.append(
        _build_component_status(
            name="action_execute_pipeline",
            ok=pipeline_ready,
            details={
                "initialized": pipeline_ready,
                "close_supported": pipeline_close_available,
                **({"error": pipeline_error} if pipeline_error else {}),
            },
        ),
    )

    telemetry_ok = True
    telemetry_error: str | None = None
    telemetry_recent_count = 0
    try:
        recent = read_telemetry_events(limit=5)
        telemetry_recent_count = len(recent)
    except Exception as exc:
        telemetry_ok = False
        telemetry_error = str(exc)

    checks.append(
        _build_component_status(
            name="telemetry_store",
            ok=telemetry_ok,
            details={
                "recent_events_checked": telemetry_recent_count,
                **({"error": telemetry_error} if telemetry_error else {}),
            },
        ),
    )

    review_ok = True
    review_error: str | None = None
    review_summary: dict[str, Any] = {}
    try:
        review_summary = get_review_queue_summary()
    except Exception as exc:
        review_ok = False
        review_error = str(exc)

    checks.append(
        _build_component_status(
            name="review_queue",
            ok=review_ok,
            details={
                "pending_items": review_summary.get("pending_items"),
                "critical_items": review_summary.get("critical_items"),
                "total_items": review_summary.get("total_items"),
                **({"error": review_error} if review_error else {}),
            },
        ),
    )

    # ── production-quality signals absorbed from app_init.py ──────────────
    checks.append(_probe_prompt_guard())
    checks.append(_probe_scanner_service())
    checks.append(_probe_history_service())

    return checks


def _overall_status_from_checks(checks: list[ComponentStatus]) -> tuple[str, bool]:
    ready = all(check.status == OK_STATUS for check in checks)
    return (OK_STATUS if ready else DEGRADED_STATUS, ready)


def _status_from_summary_payloads(*payloads: dict[str, Any]) -> str:
    degraded_values = {DEGRADED_STATUS, "error", "failed", "unavailable"}
    for payload in payloads:
        if payload.get("status") in degraded_values or "error" in payload:
            return DEGRADED_STATUS
    return OK_STATUS


def _build_diagnostics_snapshot() -> DiagnosticsResponse:
    now = _utc_now()
    frozen_timestamp = _iso(now)
    frozen_uptime = max(0, int((now - START_TIME).total_seconds()))

    checks = _build_readiness_checks()
    overall_status, _ = _overall_status_from_checks(checks)

    degraded_names = [c.name for c in checks if c.status == DEGRADED_STATUS]
    summary = f"Degraded components: {', '.join(degraded_names)}." if degraded_names else "All components operational."

    items: list[dict[str, Any]] = []
    try:
        recent = read_telemetry_events(limit=10)
        items = [e for e in recent if isinstance(e, dict)]
    except Exception:
        pass

    return DiagnosticsResponse(
        status=overall_status,
        title=f"{SERVICE_NAME} Diagnostics",
        summary=summary,
        service=SERVICE_NAME,
        version=_resolve_version(),
        timestamp=frozen_timestamp,
        uptime_seconds=frozen_uptime,
        checks=checks,
        items=items,
    )


@router.get("/live", response_model=LivenessResponse, summary="Liveness probe")
def get_liveness() -> LivenessResponse:
    response = LivenessResponse(
        status=OK_STATUS,
        **_base_response_fields(),
    )
    _safe_append_telemetry_event(
        "system_liveness_requested",
        {"status": response.status, "uptime_seconds": response.uptime_seconds},
    )
    return response


@router.get("/ready", response_model=ReadinessResponse, summary="Readiness probe")
def get_readiness(response: Response) -> ReadinessResponse:
    checks = _build_readiness_checks()
    overall_status, ready = _overall_status_from_checks(checks)
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    result = ReadinessResponse(
        status=overall_status,
        checks=checks,
        **_base_response_fields(),
    )
    _safe_append_telemetry_event(
        "system_readiness_requested",
        {"status": result.status, "ready": ready, "check_count": len(checks)},
    )
    return result


@router.get("/health", response_model=HealthResponse, summary="Combined health snapshot")
def get_health(response: Response) -> HealthResponse:
    checks = _build_readiness_checks()
    overall_status, ready = _overall_status_from_checks(checks)
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    result = HealthResponse(
        status=overall_status,
        live=True,
        ready=ready,
        checks=checks,
        **_base_response_fields(),
    )
    _safe_append_telemetry_event(
        "system_health_requested",
        {
            "status": result.status,
            "live": result.live,
            "ready": result.ready,
            "check_count": len(checks),
        },
    )
    return result


@router.get(
    "/metrics/summary",
    response_model=MetricsSummaryResponse,
    summary="Lightweight metrics and telemetry summary",
)
def get_metrics_summary() -> MetricsSummaryResponse:
    telemetry_summary: dict[str, Any]
    try:
        telemetry_summary = summarize_telemetry_events(limit=500)
    except Exception as exc:
        telemetry_summary = {"status": DEGRADED_STATUS, "error": str(exc)}

    review_summary: dict[str, Any]
    try:
        review_summary = get_review_queue_summary()
    except Exception as exc:
        review_summary = {"status": DEGRADED_STATUS, "error": str(exc)}

    recent_events: list[dict[str, Any]]
    try:
        recent_events = read_telemetry_events(limit=25)
    except Exception as exc:
        recent_events = [{"type": "telemetry_read_error", "error": str(exc)}]

    overall_status = _status_from_summary_payloads(telemetry_summary, review_summary)
    result = MetricsSummaryResponse(
        status=overall_status,
        telemetry_summary=telemetry_summary,
        review_summary=review_summary,
        recent_telemetry_events=recent_events,
        **_base_response_fields(),
    )
    _safe_append_telemetry_event(
        "system_metrics_summary_requested",
        {
            "status": result.status,
            "telemetry_event_count": len(recent_events),
            "has_review_summary": bool(review_summary),
        },
    )
    return result


@router.get(
    "/diagnostics",
    response_model=DiagnosticsResponse,
    summary="Full system diagnostics snapshot",
)
def get_diagnostics() -> DiagnosticsResponse:
    global _diagnostics_cache, _diagnostics_cache_key

    cache_key = _iso(_utc_now())[:19]

    if _diagnostics_cache is not None and _diagnostics_cache_key == cache_key:
        return DiagnosticsResponse(**_diagnostics_cache)

    result = _build_diagnostics_snapshot()
    _diagnostics_cache = result.model_dump()
    _diagnostics_cache_key = cache_key

    _safe_append_telemetry_event(
        "system_diagnostics_requested",
        {
            "status": result.status,
            "check_count": len(result.checks),
            "item_count": len(result.items),
        },
    )

    return result
