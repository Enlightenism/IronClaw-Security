from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from app.config import RISK_THRESHOLD_BLOCK_MIN
from app.services.guard_security_brain import GuardMode
from app.ui.guard.brain_status import build_guard_brain_status_view
from app.ui.guard.control_panel import CONTROL_FLAGS
from app.ui.guard.incidents import _INCIDENTS, IncidentSeverity, seed_demo_incidents
from app.ui.guard.request_stream import _REQUEST_EVENTS, seed_demo_requests

router = APIRouter(
    prefix="/ui/guard",
    tags=["guard-posture-summary"],
)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass(slots=True)
class DomainPostureScore:
    name: str
    score: int
    max_score: int = 100
    weight: float = 1.0
    rationale: str = ""
    indicators: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "score": self.score,
            "max_score": self.max_score,
            "weight": self.weight,
            "rationale": self.rationale,
            "indicators": dict(self.indicators),
        }


@dataclass(slots=True)
class GlobalPostureSummary:
    overall_score: int
    domains: list[DomainPostureScore]
    generated_at: str
    mode: GuardMode
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall_score": self.overall_score,
            "domains": [domain.to_dict() for domain in self.domains],
            "generated_at": self.generated_at,
            "mode": self.mode,
            "metadata": dict(self.metadata),
        }


class DomainPostureScoreView(BaseModel):
    name: str
    score: int
    max_score: int = 100
    weight: float = 1.0
    rationale: str
    indicators: dict[str, Any] = Field(default_factory=dict)


class GlobalPostureSummaryResponse(BaseModel):
    overall_score: int
    domains: list[DomainPostureScoreView]
    generated_at: str
    mode: GuardMode
    metadata: dict[str, Any] = Field(default_factory=dict)


def _clamp_score(value: float, min_v: int = 0, max_v: int = 100) -> int:
    return max(min_v, min(int(round(value)), max_v))


def _seed_runtime_state(mode: GuardMode) -> None:
    seed_demo_incidents()
    seed_demo_requests(mode=mode)


def _score_runtime_actions(mode: GuardMode) -> DomainPostureScore:
    brain_view = build_guard_brain_status_view(mode=mode)
    status = brain_view.status

    total = max(status.total_evaluations, 1)
    blocked = status.blocked_count
    quarantined = 0
    warned = 0
    allowed = status.allowed_count

    high_risk_ratio = blocked / total

    base = 100.0
    base -= high_risk_ratio * 60.0

    if mode in ("assist", "enforce"):
        base += 5.0
    elif mode == "disabled":
        base -= 10.0

    score = _clamp_score(base)

    rationale = f"Based on {total} recent decisions: {blocked} blocked, {allowed} allowed."

    return DomainPostureScore(
        name="runtime_actions",
        score=score,
        weight=0.35,
        rationale=rationale,
        indicators={
            "total_decisions": total,
            "blocked": blocked,
            "quarantined": quarantined,
            "warned": warned,
            "allowed": allowed,
            "high_risk_ratio": round(high_risk_ratio, 3),
            "warn_ratio": 0.0,
            "health": status.health,
            "last_verdict": status.last_verdict,
            "last_risk_score": status.last_risk_score,
            "recent_signals": list(status.recent_signals),
        },
    )


def _score_control_hygiene(mode: GuardMode) -> DomainPostureScore:
    flags = CONTROL_FLAGS

    base = 100.0

    if flags.mode == "disabled":
        base -= 40.0
    elif flags.mode == "observe":
        base -= 20.0
    elif flags.mode == "assist":
        base -= 5.0

    if flags.allow_shell_commands:
        base -= 20.0
    if flags.allow_network:
        base -= 5.0
    if flags.allow_file_write:
        base -= 5.0
    if flags.allow_prompt_injection_testing:
        base -= 15.0
    if flags.log_only_mode:
        base -= 20.0
    if flags.maintenance_mode:
        base -= 10.0

    score = _clamp_score(base)

    rationale = f"Current mode is '{flags.mode}' with runtime toggles affecting enforcement strength and attack surface."

    return DomainPostureScore(
        name="control_hygiene",
        score=score,
        weight=0.30,
        rationale=rationale,
        indicators={
            "mode": flags.mode,
            "requested_mode": mode,
            "allow_shell_commands": flags.allow_shell_commands,
            "allow_network": flags.allow_network,
            "allow_file_write": flags.allow_file_write,
            "allow_prompt_injection_testing": flags.allow_prompt_injection_testing,
            "log_only_mode": flags.log_only_mode,
            "maintenance_mode": flags.maintenance_mode,
            "updated_at": flags.updated_at,
            "updated_by": flags.updated_by,
        },
    )


def _score_incident_pressure(mode: GuardMode) -> DomainPostureScore:
    del mode

    open_incidents = [incident for incident in _INCIDENTS if incident.status == "open"]
    total_open = len(open_incidents)

    counts_by_severity: dict[IncidentSeverity, int] = {
        "low": 0,
        "medium": 0,
        "high": 0,
        "critical": 0,
    }
    for incident in open_incidents:
        counts_by_severity[incident.severity] += 1

    high_count = counts_by_severity["high"]
    critical_count = counts_by_severity["critical"]
    medium_count = counts_by_severity["medium"]

    base = 100.0
    base -= total_open * 6.0
    base -= medium_count * 4.0
    base -= high_count * 10.0
    base -= critical_count * 18.0

    newest_open_incident_at = max((incident.created_at for incident in open_incidents), default=None) if open_incidents else None

    score = _clamp_score(base)

    rationale = f"{total_open} open incidents with {high_count} high and {critical_count} critical requiring attention."

    return DomainPostureScore(
        name="incident_pressure",
        score=score,
        weight=0.20,
        rationale=rationale,
        indicators={
            "open_incidents": total_open,
            "by_severity": counts_by_severity,
            "high_open": high_count,
            "critical_open": critical_count,
            "medium_open": medium_count,
            "newest_open_incident_at": newest_open_incident_at,
        },
    )


def _score_request_stream_exposure(mode: GuardMode) -> DomainPostureScore:
    del mode

    recent_events = list(_REQUEST_EVENTS[-100:])
    total = len(recent_events)

    high_risk = sum(1 for event in recent_events if event.risk_score >= RISK_THRESHOLD_BLOCK_MIN or event.verdict == "block")
    # Keep the legacy indicator name; current decisions counted here are block-only.
    blocked_or_quarantined = sum(1 for event in recent_events if event.verdict == "block")
    prompt_injection_signals = sum(1 for event in recent_events if any(signal == "prompt_injection" for signal in event.signals))
    credential_leak_signals = sum(1 for event in recent_events if any(signal == "credential_leak" for signal in event.signals))
    data_exfiltration_signals = sum(1 for event in recent_events if any(signal == "data_exfiltration" for signal in event.signals))

    if total == 0:
        base = 100.0
        high_risk_ratio = 0.0
        blocked_ratio = 0.0
    else:
        high_risk_ratio = high_risk / total
        blocked_ratio = blocked_or_quarantined / total
        base = 100.0
        base -= high_risk_ratio * 45.0
        base -= blocked_ratio * 20.0
        base -= prompt_injection_signals * 2.0
        base -= credential_leak_signals * 3.0
        base -= data_exfiltration_signals * 4.0

    score = _clamp_score(base)
    last_event_at = recent_events[-1].occurred_at if recent_events else None

    rationale = f"Recent stream has {total} requests, {high_risk} high-risk evaluations, and {blocked_or_quarantined} blocked outcomes."

    return DomainPostureScore(
        name="request_stream_exposure",
        score=score,
        weight=0.15,
        rationale=rationale,
        indicators={
            "recent_requests": total,
            "high_risk_requests": high_risk,
            "blocked_or_quarantined": blocked_or_quarantined,
            "high_risk_ratio": round(high_risk_ratio, 3),
            "blocked_ratio": round(blocked_ratio, 3),
            "prompt_injection_signals": prompt_injection_signals,
            "credential_leak_signals": credential_leak_signals,
            "data_exfiltration_signals": data_exfiltration_signals,
            "last_event_at": last_event_at,
        },
    )


def build_global_posture_summary(mode: GuardMode | None = None) -> GlobalPostureSummary:
    effective_mode: GuardMode = mode or CONTROL_FLAGS.mode
    _seed_runtime_state(effective_mode)

    domains = [
        _score_runtime_actions(effective_mode),
        _score_control_hygiene(effective_mode),
        _score_incident_pressure(effective_mode),
        _score_request_stream_exposure(effective_mode),
    ]

    total_weight = sum(domain.weight for domain in domains) or 1.0
    weighted_score = sum(domain.score * domain.weight for domain in domains) / total_weight
    overall_score = _clamp_score(weighted_score)

    metadata = {
        "source": "ui-guard-posture-summary",
        "version": "v1",
        "domain_count": len(domains),
        "weights": {domain.name: domain.weight for domain in domains},
        "control_mode": CONTROL_FLAGS.mode,
    }

    return GlobalPostureSummary(
        overall_score=overall_score,
        domains=domains,
        generated_at=_utc_now(),
        mode=effective_mode,
        metadata=metadata,
    )


@router.get("/posture-summary", response_model=GlobalPostureSummaryResponse)
def get_posture_summary() -> GlobalPostureSummaryResponse:
    summary = build_global_posture_summary()
    data = summary.to_dict()

    return GlobalPostureSummaryResponse(
        overall_score=data["overall_score"],
        domains=[DomainPostureScoreView(**domain) for domain in data["domains"]],
        generated_at=data["generated_at"],
        mode=data["mode"],
        metadata=data["metadata"],
    )
