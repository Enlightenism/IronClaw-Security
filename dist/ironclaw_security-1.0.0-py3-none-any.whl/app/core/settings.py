from __future__ import annotations

import functools
import logging
import os
from urllib.parse import urlparse

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

_logger = logging.getLogger(__name__)

_CANONICAL_PRODUCTION_ORIGINS = [
    "https://moving-forward.ca",
    "https://www.moving-forward.ca",
    "https://ironclaw-security.pages.dev",
]
_CANONICAL_LOCAL_ORIGINS = [
    "http://localhost",
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
]
_CANONICAL_ALLOWED_ORIGINS = [
    *_CANONICAL_PRODUCTION_ORIGINS,
    *_CANONICAL_LOCAL_ORIGINS,
]
_CANONICAL_TRUSTED_HOSTS = [
    "moving-forward.ca",
    "www.moving-forward.ca",
    "ironclaw-security.pages.dev",
    "localhost",
    "127.0.0.1",
    "0.0.0.0",
    "testserver",
]


def _require_env(name: str) -> str:
    value = _normalize_string(os.getenv(name))
    if not value:
        raise RuntimeError(f"{name} is not set")
    return value


def _get_vault():
    from app.services.secrets_vault import vault

    return vault


def _normalize_string(value: str | None) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip()


def _strip_wrappers(value: str) -> str:
    cleaned = _normalize_string(value).strip("\"'").strip()

    if cleaned.startswith("[") and "](" in cleaned and cleaned.endswith(")"):
        cleaned = cleaned[cleaned.index("](") + 2 : -1].strip()

    if cleaned.startswith("[") and cleaned.endswith("]"):
        cleaned = cleaned[1:-1].strip()

    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = cleaned[1:-1].strip()

    return cleaned.strip().strip("\"'").strip()


def _csv_to_list(value: str | None) -> list[str]:
    normalized = _normalize_string(value)
    if not normalized:
        return []
    return [_strip_wrappers(item) for item in normalized.split(",") if _strip_wrappers(item)]


def _normalize_unique(values: list[str]) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()

    for value in values:
        item = _normalize_string(value)
        if not item:
            continue

        key = item.lower()
        if key in seen:
            continue

        seen.add(key)
        normalized.append(item)

    return normalized


def _normalize_origin(origin: str) -> str:
    value = _strip_wrappers(origin)
    if not value:
        return ""

    if value == "*":
        return "*"

    parsed = urlparse(value)
    if not parsed.scheme or not parsed.netloc:
        return value.rstrip("/")

    return f"{parsed.scheme.lower()}://{parsed.netloc.lower()}"


def _normalize_host(value: str) -> str:
    host = _strip_wrappers(value)
    if not host:
        return ""

    if host == "*":
        return "*"

    if "://" in host:
        parsed = urlparse(host)
        host = parsed.netloc or parsed.path

    host = host.strip().strip("/").lower()

    if host.startswith("*."):
        return host

    if ":" in host and not host.startswith("["):
        hostname, _, port = host.partition(":")
        if port.isdigit():
            host = hostname

    return host.removeprefix("www.")


def _host_from_url(value: str) -> str:
    normalized = _normalize_origin(value)
    if not normalized or normalized == "*":
        return ""

    parsed = urlparse(normalized)
    return _normalize_host(parsed.netloc)


def _is_local_development_host(host: str) -> bool:
    normalized = _normalize_host(host)
    return normalized in {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
        "testserver",
    }


def _optional_env_file() -> str | None:
    value = _normalize_string(os.getenv("IRONCLAW_ENV_FILE"))
    return value or None


def _sanitize_secret(value: str | None) -> str:
    normalized = _normalize_string(value)
    if not normalized:
        return ""
    return normalized


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        populate_by_name=True,
        extra="ignore",
        env_file=_optional_env_file(),
        env_file_encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # Core identity
    # ------------------------------------------------------------------
    app_name: str = Field(default="IronClaw-Security", alias="APP_NAME")
    app_version: str = Field(default="0.1.0", alias="APP_VERSION")
    app_host: str = Field(default="127.0.0.1", alias="APP_HOST")
    app_port: int = Field(default=8000, alias="APP_PORT")
    app_base_url: str = Field(default="", alias="APP_BASE_URL")
    api_prefix: str = Field(default="", alias="API_PREFIX")
    debug: bool = Field(default=False, alias="DEBUG")
    reload: bool = Field(default=False, alias="RELOAD")

    # ------------------------------------------------------------------
    # Environment / logging
    # ------------------------------------------------------------------
    environment: str = Field(default="development", alias="ENVIRONMENT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    structured_logging_enabled: bool = Field(
        default=True,
        alias="STRUCTURED_LOGGING_ENABLED",
    )

    # ------------------------------------------------------------------
    # Authentication
    # ------------------------------------------------------------------
    auth_required: bool = Field(default=False, alias="AUTH_REQUIRED")
    api_key: str = Field(default="", alias="API_KEY")
    admin_api_key: str = Field(default="", alias="ADMIN_API_KEY")
    platform_api_key: str = Field(default="", alias="PLATFORM_API_KEY")
    internal_platform_api_key: str = Field(
        default="",
        alias="INTERNAL_PLATFORM_API_KEY",
    )
    ironclaw_api_key: str = Field(default="", alias="IRONCLAW_API_KEY")

    # ------------------------------------------------------------------
    # Auth / JWT
    # ------------------------------------------------------------------
    secret_key: str = Field(
        default_factory=lambda: _require_env("IRONCLAW_SECRET_KEY"),
        alias="IRONCLAW_SECRET_KEY",
    )
    jwt_algorithm: str = Field(default="", alias="JWT_ALGORITHM")
    jwt_private_key: str | None = Field(default=None, alias="JWT_PRIVATE_KEY")
    jwt_public_key: str | None = Field(default=None, alias="JWT_PUBLIC_KEY")
    jwt_secret: str | None = Field(default=None, alias="JWT_SECRET")
    access_token_expire_minutes: int = Field(
        default=30,
        alias="ACCESS_TOKEN_EXPIRE_MINUTES",
    )

    # ------------------------------------------------------------------
    # IronClaw Auth Edge Function
    # ------------------------------------------------------------------
    ironclaw_auth_edge_fn_path: str = Field(
        default="",
        alias="IRONCLAW_AUTH_EDGE_FN_PATH",
    )
    ironclaw_auth_edge_fn_timeout_seconds: float = Field(
        default=10.0,
        alias="IRONCLAW_AUTH_EDGE_FN_TIMEOUT_SECONDS",
    )

    # ------------------------------------------------------------------
    # Supabase
    # ------------------------------------------------------------------
    supabase_url: str = Field(default="", alias="SUPABASE_URL")
    supabase_key: str = Field(default="", alias="SUPABASE_KEY")
    supabase_anon_key: str = Field(default="", alias="SUPABASE_ANON_KEY")
    supabase_service_role_key: str = Field(
        default="",
        alias="SUPABASE_SERVICE_ROLE_KEY",
    )
    persistence_mode: str = Field(
        default="memory",
        alias="IRONCLAW_PERSISTENCE_MODE",
    )

    # ------------------------------------------------------------------
    # Local prompt guard
    # ------------------------------------------------------------------
    guard_enabled: bool = Field(default=False, alias="GUARD_ENABLED")
    guard_model_path: str = Field(
        default="models/prompt-guard-86m",
        alias="GUARD_MODEL_PATH",
    )
    guard_threshold: float = Field(default=0.5, alias="GUARD_THRESHOLD")

    # ------------------------------------------------------------------
    # OpenAI
    # ------------------------------------------------------------------
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")

    # ------------------------------------------------------------------
    # Stripe
    # ------------------------------------------------------------------
    stripe_secret_key: str = Field(default="", alias="STRIPE_SECRET_KEY")
    stripe_publishable_key: str = Field(
        default="",
        alias="STRIPE_PUBLISHABLE_KEY",
    )
    stripe_webhook_secret: str = Field(default="", alias="STRIPE_WEBHOOK_SECRET")

    # ------------------------------------------------------------------
    # Policy / verdict defaults
    # ------------------------------------------------------------------
    default_scan_verdict: str = Field(default="allow", alias="DEFAULT_SCAN_VERDICT")
    default_review_status: str = Field(
        default="not_required",
        alias="DEFAULT_REVIEW_STATUS",
    )

    # ------------------------------------------------------------------
    # Risk thresholds
    # ------------------------------------------------------------------
    risk_threshold_allow_max: int = Field(
        default=29,
        alias="RISK_THRESHOLD_ALLOW_MAX",
    )
    risk_threshold_quarantine_min: int = Field(
        default=30,
        alias="RISK_THRESHOLD_QUARANTINE_MIN",
    )
    risk_threshold_block_min: int = Field(
        default=70,
        alias="RISK_THRESHOLD_BLOCK_MIN",
    )

    # ------------------------------------------------------------------
    # Input size limits
    # ------------------------------------------------------------------
    max_text_chars: int = Field(default=100_000, alias="MAX_TEXT_CHARS")
    max_url_length: int = Field(default=2048, alias="MAX_URL_LENGTH")
    max_archive_name_length: int = Field(
        default=512,
        alias="MAX_ARCHIVE_NAME_LENGTH",
    )
    max_repo_url_length: int = Field(default=2048, alias="MAX_REPO_URL_LENGTH")

    # ------------------------------------------------------------------
    # Filesystem paths
    # ------------------------------------------------------------------
    data_dir: str = Field(default="samples", alias="DATA_DIR")
    backup_dir: str = Field(default="./data/backups", alias="BACKUP_DIR")
    reports_dir: str | None = Field(default=None, alias="REPORTS_DIR")
    uploads_dir: str | None = Field(default=None, alias="UPLOADS_DIR")
    quarantine_dir: str | None = Field(default=None, alias="QUARANTINE_DIR")

    # ------------------------------------------------------------------
    # CORS — primary env var: ALLOWED_ORIGINS
    # Legacy fallback env var: CORS_ORIGINS.
    # Keep both fields so env injection and compatibility logic remain intact.
    # ------------------------------------------------------------------
    allowed_origins: str = Field(
        default=",".join(_CANONICAL_ALLOWED_ORIGINS),
        alias="ALLOWED_ORIGINS",
    )
    cors_origins: str = Field(
        default=",".join(_CANONICAL_ALLOWED_ORIGINS),
        alias="CORS_ORIGINS",
    )
    cors_allowed_methods: str = Field(default="", alias="CORS_ALLOWED_METHODS")
    cors_allowed_headers: str = Field(default="", alias="CORS_ALLOWED_HEADERS")
    cors_expose_headers: str = Field(default="", alias="CORS_EXPOSE_HEADERS")
    cors_allow_credentials: bool | None = Field(
        default=None,
        alias="CORS_ALLOW_CREDENTIALS",
    )

    # ------------------------------------------------------------------
    # Trusted hosts / response hardening
    # ------------------------------------------------------------------
    trusted_hosts: str = Field(
        default=",".join(_CANONICAL_TRUSTED_HOSTS),
        alias="TRUSTED_HOSTS",
    )
    enable_hsts: bool = Field(default=True, alias="ENABLE_HSTS")
    content_security_policy: str = Field(default="", alias="CONTENT_SECURITY_POLICY")

    # ------------------------------------------------------------------
    # Stripe redirect validation
    # ------------------------------------------------------------------
    allowed_redirect_hosts: str = Field(
        default="",
        alias="ALLOWED_REDIRECT_HOSTS",
        description="Comma-separated list of allowed hosts for Stripe success/cancel URLs. Production frontend origin should be included.",
    )

    # ------------------------------------------------------------------
    # Optional integrations
    # ------------------------------------------------------------------
    redis_url: str | None = Field(default=None, alias="REDIS_URL")
    sentry_dsn: str | None = Field(default=None, alias="SENTRY_DSN")

    # ------------------------------------------------------------------
    # Engine
    # ------------------------------------------------------------------
    engine_base_url: str = Field(
        default="http://127.0.0.1:8010",
        alias="ENGINE_BASE_URL",
    )

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------
    @property
    def is_production(self) -> bool:
        return _normalize_string(self.environment).lower() == "production"

    @property
    def effective_api_key(self) -> str:
        for value in (
            self.ironclaw_api_key,
            self.internal_platform_api_key,
            self.platform_api_key,
            self.admin_api_key,
            self.api_key,
        ):
            normalized = _normalize_string(value)
            if normalized:
                return normalized

        return ""

    @property
    def effective_platform_api_key(self) -> str:
        return self.effective_api_key

    @property
    def effective_secret_key(self) -> str:
        vault = _get_vault()
        vault_secret = _sanitize_secret(vault.secret_key())
        if vault_secret:
            return vault_secret

        return _sanitize_secret(self.secret_key)

    @property
    def effective_jwt_secret(self) -> str:
        vault = _get_vault()
        vault_jwt_secret = _sanitize_secret(vault.jwt_secret())
        if vault_jwt_secret:
            return vault_jwt_secret

        vault_supabase_jwt_secret = _sanitize_secret(
            vault.supabase_jwt_secret(),
        )
        if vault_supabase_jwt_secret:
            return vault_supabase_jwt_secret

        return _sanitize_secret(self.jwt_secret)

    @property
    def effective_supabase_jwt_secret(self) -> str:
        vault = _get_vault()
        return _sanitize_secret(vault.supabase_jwt_secret())

    @property
    def effective_jwt_algorithm(self) -> str:
        configured = _normalize_string(self.jwt_algorithm).upper()
        if configured:
            return configured

        legacy_algorithm = _normalize_string(
            os.getenv("SUPABASE_JWT_ALGORITHM"),
        ).upper()
        if legacy_algorithm:
            return legacy_algorithm

        return "HS256"

    @property
    def jwt_algorithm_is_asymmetric(self) -> bool:
        return self.effective_jwt_algorithm.startswith(("ES", "RS"))

    @property
    def jwt_algorithm_is_symmetric(self) -> bool:
        return self.effective_jwt_algorithm.startswith("HS")

    @property
    def jwt_public_key_pem(self) -> str | None:
        value = _sanitize_secret(self.jwt_public_key)
        return value or None

    @property
    def jwt_private_key_pem(self) -> str | None:
        value = _sanitize_secret(self.jwt_private_key)
        return value or None

    @property
    def jwt_keys_configured(self) -> bool:
        if self.jwt_algorithm_is_asymmetric:
            return bool(self.jwt_public_key_pem)

        if self.jwt_algorithm_is_symmetric:
            return bool(self.effective_jwt_secret)

        return False

    @property
    def jwt_keys_missing(self) -> bool:
        return not self.jwt_keys_configured

    @property
    def allowed_jwt_algorithms(self) -> list[str]:
        return [self.effective_jwt_algorithm]

    @property
    def effective_supabase_url(self) -> str:
        return _normalize_string(self.supabase_url)

    @property
    def effective_supabase_anon_key(self) -> str:
        return _normalize_string(self.supabase_anon_key)

    @property
    def effective_supabase_service_role_key(self) -> str:
        return _normalize_string(self.supabase_service_role_key)

    @property
    def bearer_auth_configured(self) -> bool:
        return bool(self.effective_supabase_url and (self.effective_supabase_anon_key or self.effective_supabase_service_role_key or self.effective_supabase_jwt_secret or self.effective_jwt_secret or self.jwt_public_key_pem))

    @property
    def api_key_auth_configured(self) -> bool:
        return bool(self.effective_api_key)

    @property
    def auth_configured(self) -> bool:
        return self.api_key_auth_configured or self.bearer_auth_configured

    @property
    def effective_auth_required(self) -> bool:
        return bool(self.auth_required and self.auth_configured)

    @property
    def normalized_app_base_url(self) -> str:
        return _normalize_origin(self.app_base_url)

    @property
    def normalized_engine_base_url(self) -> str:
        return _normalize_origin(self.engine_base_url)

    @property
    def effective_allowed_origins(self) -> list[str]:
        primary = _normalize_unique(
            [_normalize_origin(item) for item in _csv_to_list(self.allowed_origins) if item.strip()],
        )
        if primary:
            return primary

        legacy = _normalize_unique(
            [_normalize_origin(item) for item in _csv_to_list(self.cors_origins) if item.strip()],
        )
        if legacy:
            return legacy

        if self.is_production:
            return []

        return [
            "http://localhost",
            "http://localhost:3000",
            "http://localhost:5173",
            "http://127.0.0.1",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:5173",
        ]

    @property
    def effective_trusted_hosts(self) -> list[str]:
        configured_hosts = _csv_to_list(self.trusted_hosts)
        if configured_hosts:
            normalized_hosts = _normalize_unique(
                [normalized for item in configured_hosts if (normalized := _normalize_host(item))],
            )
            return normalized_hosts or ["*"]

        derived_hosts: list[str] = []

        for origin in self.effective_allowed_origins:
            if origin == "*":
                return ["*"]

            host = _host_from_url(origin)
            if host:
                derived_hosts.append(host)

        for base_url in (
            self.normalized_app_base_url,
            self.normalized_engine_base_url,
        ):
            host = _host_from_url(base_url)
            if not host:
                continue

            if self.is_production and _is_local_development_host(host):
                continue

            derived_hosts.append(host)

        normalized_derived = _normalize_unique(derived_hosts)
        return normalized_derived or ["*"]

    @property
    def effective_allowed_redirect_hosts(self) -> list[str]:
        explicit = _normalize_unique(
            [_normalize_host(item) for item in _csv_to_list(self.allowed_redirect_hosts) if item.strip()],
        )
        if explicit:
            return explicit

        derived: list[str] = []

        for origin in self.effective_allowed_origins:
            if origin == "*":
                return ["*"]

            host = _host_from_url(origin)
            if host:
                derived.append(host)

        for base_url in (self.normalized_app_base_url,):
            host = _host_from_url(base_url)
            if host:
                derived.append(host)

        normalized = _normalize_unique(derived)
        return normalized or ["*"]

    def log_auth_diagnostics(self) -> None:
        algorithm = self.effective_jwt_algorithm

        _logger.info(
            "JWT/Supabase auth configuration: supabase_jwt_secret_configured=%s effective_jwt_algorithm=%s supabase_url_configured=%s supabase_api_key_configured=%s jwt_keys_configured=%s",
            bool(self.effective_supabase_jwt_secret),
            algorithm,
            bool(self.effective_supabase_url),
            bool(self.effective_supabase_anon_key or self.effective_supabase_service_role_key),
            self.jwt_keys_configured,
        )

        if self.jwt_algorithm_is_asymmetric and not self.jwt_public_key_pem:
            _logger.warning(
                "JWT asymmetric algorithm configured but JWT_PUBLIC_KEY is missing: effective_jwt_algorithm=%s",
                algorithm,
            )

        if self.jwt_algorithm_is_symmetric and not self.effective_jwt_secret:
            _logger.warning(
                "JWT symmetric algorithm configured but JWT_SECRET is missing: effective_jwt_algorithm=%s",
                algorithm,
            )


@functools.lru_cache(maxsize=1)
def get_settings() -> Settings:
    settings = Settings(debug=False, reload=False)
    settings.log_auth_diagnostics()
    return settings
