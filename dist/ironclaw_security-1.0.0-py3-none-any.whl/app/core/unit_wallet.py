from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
import logging
import math
import os
import re
from threading import Lock
from typing import Any
import uuid

from app.supabaseclient import TOKENS_PER_UNIT as TOKEN_CHUNK_SIZE

logger = logging.getLogger(__name__)

__all__ = [
    "TOKEN_CHUNK_SIZE",
    "ORG_KEY_PREFIX",
    "is_org_key",
    "InsufficientUnitsError",
    "units_required_for_tokens",
    "UNIT_PACKAGE_CATALOG",
    "UnitWalletTransaction",
    "UnitLedgerEntry",
    "InstallKeyUsageSource",
    "InstallKeyUsageLedgerEntry",
    "UnitWallet",
    "RegistryUnitWallet",
    "RegistryUnitLedgerEntry",
    "SupabaseUnitWalletRepository",
    "MemoryUnitWalletRepository",
    "UnitWalletRegistry",
    "get_unit_wallet_registry",
]

ORG_KEY_PREFIX: str = "ic_org_"


def _normalize_owner_key(owner_key: str) -> str:
    return str(owner_key).strip().lower()


def _durable_storage_required() -> bool:
    persistence_mode = os.environ.get("IRONCLAW_PERSISTENCE_MODE", "").strip().lower()
    environment_name = (os.environ.get("IRONCLAW_ENV") or os.environ.get("APP_ENV") or os.environ.get("ENVIRONMENT", "")).strip().lower()
    return persistence_mode == "supabase" or environment_name in {"prod", "production"}


def _is_generic_platform_credential(value: str | None) -> bool:
    if value is None:
        return False
    candidate = str(value).strip().lower()
    if not candidate:
        return False
    generic_prefixes = (
        "sk_",
        "ghp_",
        "gho_",
        "github_pat_",
        "token_",
        "secret_",
        "api_",
        "api-key",
        "api_key",
        "platform-api-key",
        "platform_api_key",
        "system-api-key",
        "system_api_key",
        "internal-platform-api-key",
        "internal_platform_api_key",
        "bearer ",
        "x-api-key",
    )
    if candidate.startswith(generic_prefixes):
        return True
    if "platform" in candidate and ("key" in candidate or "token" in candidate or "secret" in candidate):
        return True
    if "api" in candidate and "key" in candidate:
        return True
    return False


def is_org_key(owner_key: str) -> bool:
    return _normalize_owner_key(owner_key).startswith(ORG_KEY_PREFIX)


class InsufficientUnitsError(ValueError):
    def __init__(
        self,
        message: str = "Insufficient protection units",
        *,
        have: int = 0,
        need: int = 0,
        owner_key: str = "",
    ) -> None:
        super().__init__(message)
        self.have = int(have)
        self.need = int(need)
        self.owner_key = str(owner_key)


def units_required_for_tokens(token_count: int) -> int:
    if token_count <= 0:
        return 0
    return math.ceil(token_count / TOKEN_CHUNK_SIZE)


def _build_package_catalog() -> dict[str, dict[str, Any]]:
    from app.core.billing import UNIT_PACKAGE_CATALOG

    return {
        entry["package_id"]: {
            "package_id": entry["package_id"],
            "code": entry["code"],
            "aliases": entry["aliases"],
            "name": entry["name"],
            "unit_amount": entry["units"],
            "price_usd": float(entry["price_usd"]),
            "display_label": entry["display_label"],
            "description": entry["description"],
            "tokens_per_unit": entry["tokens_per_unit"],
            "token_coverage": entry["token_coverage"],
            "featured": entry["featured"],
        }
        for entry in UNIT_PACKAGE_CATALOG
    }


UNIT_PACKAGE_CATALOG: dict[str, dict[str, Any]] = _build_package_catalog()

_WALLET_CACHE_MAX: int = 5_000
_LEDGER_MAX_SIZE: int = 10_000


@dataclass
class UnitWalletTransaction:
    transaction_id: str
    owner_id: str
    transaction_type: str
    units: int
    balance_after: int
    source: str
    reference_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class UnitLedgerEntry:
    owner_id: str
    transaction: UnitWalletTransaction
    recorded_at: datetime = field(default_factory=lambda: datetime.now(UTC))


@dataclass
class InstallKeyUsageSource:
    key_id: str
    owner_key: str
    program: str
    balance_units: int = 0
    total_consumed_units: int = 0
    units_used_today: int = 0
    units_used_this_week: int = 0
    usage_event_count: int = 0
    last_action_at: datetime | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    usage_by_day: dict[str, int] = field(default_factory=dict)
    usage_by_week: dict[str, int] = field(default_factory=dict)

    def _bucket_day(self, timestamp: datetime) -> str:
        return timestamp.astimezone(UTC).date().isoformat()

    def _bucket_week(self, timestamp: datetime) -> str:
        iso_year, iso_week, _ = timestamp.astimezone(UTC).isocalendar()
        return f"{iso_year}-W{iso_week:02d}"

    def register_usage_event(
        self,
        *,
        units: int,
        occurred_at: datetime | None = None,
    ) -> None:
        if units < 0:
            raise ValueError("units must be non-negative")
        event_time = occurred_at or datetime.now(UTC)
        self.total_consumed_units += int(units)
        self.usage_event_count += 1
        self.last_action_at = event_time

        day_key = self._bucket_day(event_time)
        self.usage_by_day[day_key] = self.usage_by_day.get(day_key, 0) + int(units)
        self.units_used_today = self.usage_by_day.get(day_key, 0)

        week_key = self._bucket_week(event_time)
        self.usage_by_week[week_key] = self.usage_by_week.get(week_key, 0) + int(units)
        self.units_used_this_week = self.usage_by_week[week_key]

    def as_summary(self) -> dict[str, Any]:
        return {
            "key_id": self.key_id,
            "owner_key": self.owner_key,
            "program": self.program,
            "balance_units": self.balance_units,
            "total_consumed_units": self.total_consumed_units,
            "units_used_today": self.units_used_today,
            "units_used_this_week": self.units_used_this_week,
            "usage_event_count": self.usage_event_count,
            "last_action_at": self.last_action_at.isoformat() if self.last_action_at else None,
            "metadata": dict(self.metadata),
            "usage_by_day": dict(self.usage_by_day),
            "usage_by_week": dict(self.usage_by_week),
        }


@dataclass
class InstallKeyUsageLedgerEntry:
    entry_id: str
    owner_key: str
    key_id: str
    program: str
    action_type: str
    units: int
    balance_after: int
    payment_id: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "owner_key": self.owner_key,
            "key_id": self.key_id,
            "program": self.program,
            "action_type": self.action_type,
            "units": self.units,
            "balance_after": self.balance_after,
            "payment_id": self.payment_id,
            "created_at": self.created_at.isoformat(),
            "metadata": dict(self.metadata),
        }


@dataclass
class UnitWallet:
    owner_id: str
    balance_units: int = 0
    total_purchased_units: int = 0
    total_consumed_units: int = 0
    total_refunded_units: int = 0
    transactions: list[UnitWalletTransaction] = field(default_factory=list)
    usage_by_key: dict[str, InstallKeyUsageSource] = field(default_factory=dict)

    @property
    def owner_key(self) -> str:
        return self.owner_id

    @owner_key.setter
    def owner_key(self, value: str) -> None:
        self.owner_id = str(value).strip().lower()

    def as_summary(self) -> dict[str, Any]:
        return {
            "owner_key": self.owner_id,
            "balance_units": self.balance_units,
            "total_purchased_units": self.total_purchased_units,
            "total_consumed_units": self.total_consumed_units,
            "total_refunded_units": self.total_refunded_units,
            "install_key_usage": {key: value.as_summary() for key, value in sorted(self.usage_by_key.items())},
        }

    def get_key_usage_summary(self, key_id: str | None = None) -> dict[str, Any]:
        if key_id is not None:
            usage = self.usage_by_key.get(key_id)
            return {
                "owner_key": self.owner_id,
                "wallet_balance_units": self.balance_units,
                "total_consumed_units": self.total_consumed_units,
                "install_key_usage": {key_id: usage.as_summary()} if usage is not None else {},
            }

        return {
            "owner_key": self.owner_id,
            "wallet_balance_units": self.balance_units,
            "total_consumed_units": self.total_consumed_units,
            "install_key_usage": {key: value.as_summary() for key, value in sorted(self.usage_by_key.items())},
        }

    def purchase_units(
        self,
        units: int,
        source: str,
        reference_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UnitWalletTransaction:
        safe_units = max(0, int(units))
        self.balance_units += safe_units
        self.total_purchased_units += safe_units
        transaction = UnitWalletTransaction(
            transaction_id=f"txn_{uuid.uuid4().hex}",
            owner_id=self.owner_id,
            transaction_type="purchase",
            units=safe_units,
            balance_after=self.balance_units,
            source=source,
            reference_id=reference_id,
            metadata=metadata or {},
        )
        self.transactions.append(transaction)
        return transaction

    def consume_units(
        self,
        units: int,
        source: str,
        reference_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UnitWalletTransaction:
        safe_units = max(0, int(units))
        if safe_units > self.balance_units:
            raise InsufficientUnitsError(
                "Insufficient protection units",
                have=self.balance_units,
                need=safe_units,
                owner_key=self.owner_id,
            )
        self.balance_units -= safe_units
        self.total_consumed_units += safe_units
        transaction = UnitWalletTransaction(
            transaction_id=f"txn_{uuid.uuid4().hex}",
            owner_id=self.owner_id,
            transaction_type="consume",
            units=safe_units,
            balance_after=self.balance_units,
            source=source,
            reference_id=reference_id,
            metadata=metadata or {},
        )
        self.transactions.append(transaction)
        return transaction

    def consume_units_for_tokens(
        self,
        token_count: int,
        source: str,
        reference_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UnitWalletTransaction:
        required = units_required_for_tokens(token_count)
        combined_metadata = {
            "token_count": token_count,
            "tokens_per_unit": TOKEN_CHUNK_SIZE,
            "units_required": required,
            **(metadata or {}),
        }
        return self.consume_units(
            units=required,
            source=source,
            reference_id=reference_id,
            metadata=combined_metadata,
        )

    def consume_units_for_install_key(
        self,
        *,
        key_id: str,
        program: str,
        units: int,
        source: str = "install_key",
        reference_id: str | None = None,
        payment_id: str | None = None,
        action_type: str = "prompt",
        metadata: dict[str, Any] | None = None,
    ) -> tuple[UnitWalletTransaction, InstallKeyUsageSource]:
        if not key_id:
            raise ValueError("key_id is required for install-key consumption")
        if not program:
            raise ValueError("program is required for install-key consumption")
        if _is_generic_platform_credential(self.owner_id):
            raise ValueError("owner_key must be a customer or org identity, not a generic platform API key")
        if _is_generic_platform_credential(str(key_id)):
            raise ValueError("key_id must be an install key identity, not a generic platform API credential")

        payload = dict(metadata or {})
        explicit_owner = str(payload.get("owner_key") or "").strip().lower()
        if explicit_owner and explicit_owner != self.owner_id:
            raise ValueError("metadata owner_key does not match the wallet owner_key for install-key usage")
        explicit_key = str(payload.get("key_id") or "").strip()
        if explicit_key and explicit_key != str(key_id):
            raise ValueError("metadata key_id does not match the install key being debited")

        canonical_metadata = {
            **payload,
            "owner_key": self.owner_id,
            "key_id": key_id,
            "program": program,
            "payment_id": payment_id,
            "action_type": action_type,
        }

        transaction = self.consume_units(
            units,
            source=f"{source}:{key_id}",
            reference_id=reference_id,
            metadata=canonical_metadata,
        )

        summary = self.usage_by_key.setdefault(
            key_id,
            InstallKeyUsageSource(
                key_id=key_id,
                owner_key=self.owner_id,
                program=program,
            ),
        )
        if summary.owner_key != self.owner_id:
            raise ValueError("install-key usage for a different owner_key is not allowed on this wallet")
        summary.program = program
        summary.balance_units = max(self.balance_units, 0)
        summary.metadata.update(canonical_metadata)

        summary.register_usage_event(
            units=int(transaction.units),
            occurred_at=transaction.created_at,
        )

        return transaction, summary

    def refund_units(
        self,
        units: int,
        source: str,
        reference_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> UnitWalletTransaction:
        safe_units = max(0, int(units))
        self.balance_units += safe_units
        self.total_refunded_units += safe_units
        transaction = UnitWalletTransaction(
            transaction_id=f"txn_{uuid.uuid4().hex}",
            owner_id=self.owner_id,
            transaction_type="refund",
            units=safe_units,
            balance_after=self.balance_units,
            source=source,
            reference_id=reference_id,
            metadata=metadata or {},
        )
        self.transactions.append(transaction)
        return transaction


@dataclass
class RegistryUnitWallet:
    wallet_id: str
    owner_key: str
    balance_units: int = 0
    total_purchased_units: int = 0
    total_consumed_units: int = 0
    total_refunded_units: int = 0
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] = field(default_factory=dict)
    install_key_usage: dict[str, InstallKeyUsageSource] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.wallet_id = str(self.wallet_id).strip()
        self.owner_key = _normalize_owner_key(self.owner_key)
        if not self.wallet_id:
            raise ValueError("wallet_id is required")
        if not self.owner_key:
            raise ValueError("owner_key is required")
        if not isinstance(self.metadata, dict):
            self.metadata = dict(self.metadata or {})
        if not isinstance(self.install_key_usage, dict):
            self.install_key_usage = {}

    def as_summary(self) -> dict[str, Any]:
        return {
            "wallet_id": self.wallet_id,
            "owner_key": self.owner_key,
            "balance_units": self.balance_units,
            "total_purchased_units": self.total_purchased_units,
            "total_consumed_units": self.total_consumed_units,
            "total_refunded_units": self.total_refunded_units,
            "updated_at": self.updated_at.isoformat(),
            "metadata": dict(self.metadata),
            "install_key_usage": {key: value.as_summary() for key, value in sorted(self.install_key_usage.items())},
        }


@dataclass
class RegistryUnitLedgerEntry:
    entry_id: str
    wallet_id: str
    owner_key: str
    entry_type: str
    units: int
    balance_after: int
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    purchase_id: str | None = None
    checkout_session_id: str | None = None
    event_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not isinstance(self.metadata, dict):
            self.metadata = dict(self.metadata or {})

    def as_dict(self) -> dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "wallet_id": self.wallet_id,
            "owner_key": self.owner_key,
            "entry_type": self.entry_type,
            "units": self.units,
            "balance_after": self.balance_after,
            "created_at": self.created_at.isoformat(),
            "purchase_id": self.purchase_id,
            "checkout_session_id": self.checkout_session_id,
            "event_id": self.event_id,
            "metadata": dict(self.metadata),
        }


class SupabaseUnitWalletRepository:
    _WALLETS_TABLE = "unit_wallets"
    _LEDGER_TABLE = "unit_ledger"

    def __init__(self) -> None:
        from app.supabaseclient import get_supabase_client

        self._client = get_supabase_client()
        self._validate_schema()

    def _validate_schema(self) -> None:
        expected_wallet_columns = {
            "wallet_id",
            "owner_key",
            "balance_units",
            "total_purchased_units",
            "total_consumed_units",
            "total_refunded_units",
            "updated_at",
            "metadata",
        }
        expected_ledger_columns = {
            "entry_id",
            "wallet_id",
            "owner_key",
            "entry_type",
            "units",
            "balance_after",
            "created_at",
            "metadata",
        }
        for table_name, required_columns in {
            self._WALLETS_TABLE: expected_wallet_columns,
            self._LEDGER_TABLE: expected_ledger_columns,
        }.items():
            try:
                result = self._client.table(table_name).select("*").limit(1).execute()
            except Exception as exc:  # pragma: no cover - exercised via constructor tests
                raise RuntimeError(f"unit_wallet: Supabase schema drift detected for table {table_name!r}; unable to query wallet repository") from exc
            if result is None or not hasattr(result, "data"):
                raise RuntimeError(f"unit_wallet: Supabase wallet repository returned an invalid response for table {table_name!r}")
            if not result.data and not required_columns:
                continue

    def upsert_wallet(self, wallet: RegistryUnitWallet) -> None:
        self._client.table(self._WALLETS_TABLE).upsert(
            {
                "wallet_id": wallet.wallet_id,
                "owner_key": wallet.owner_key,
                "balance_units": wallet.balance_units,
                "total_purchased_units": wallet.total_purchased_units,
                "total_consumed_units": wallet.total_consumed_units,
                "total_refunded_units": wallet.total_refunded_units,
                "updated_at": wallet.updated_at.isoformat(),
                "metadata": {
                    **(wallet.metadata or {}),
                    "install_key_usage": {key: value.as_summary() for key, value in sorted(wallet.install_key_usage.items())},
                },
            },
            on_conflict="wallet_id",
        ).execute()

    def fetch_wallet(self, owner_key: str) -> RegistryUnitWallet | None:
        result = self._client.table(self._WALLETS_TABLE).select("*").eq("owner_key", owner_key).limit(1).execute()
        if not result.data:
            return None
        row = result.data[0]
        metadata = row.get("metadata") or {}
        install_key_usage_raw = metadata.get("install_key_usage") or {}
        usage_map: dict[str, InstallKeyUsageSource] = {}
        for key_id, value in install_key_usage_raw.items():
            if not isinstance(value, dict):
                continue
            usage_map[key_id] = InstallKeyUsageSource(
                key_id=str(value.get("key_id") or key_id),
                owner_key=str(value.get("owner_key") or owner_key),
                program=str(value.get("program") or "unknown"),
                balance_units=int(value.get("balance_units", 0)),
                total_consumed_units=int(value.get("total_consumed_units", 0)),
                units_used_today=int(value.get("units_used_today", 0)),
                units_used_this_week=int(value.get("units_used_this_week", 0)),
                usage_event_count=int(value.get("usage_event_count", 0)),
                last_action_at=datetime.fromisoformat(value["last_action_at"]) if value.get("last_action_at") else None,
                metadata=dict(value.get("metadata") or {}),
                usage_by_day={str(day): int(units) for day, units in (value.get("usage_by_day") or {}).items()},
                usage_by_week={str(week): int(units) for week, units in (value.get("usage_by_week") or {}).items()},
            )
        return RegistryUnitWallet(
            wallet_id=row["wallet_id"],
            owner_key=row["owner_key"],
            balance_units=row["balance_units"],
            total_purchased_units=row["total_purchased_units"],
            total_consumed_units=row["total_consumed_units"],
            total_refunded_units=row.get("total_refunded_units", 0),
            updated_at=datetime.fromisoformat(row["updated_at"]),
            metadata=metadata,
            install_key_usage=usage_map,
        )

    def append_ledger_entry(self, entry: RegistryUnitLedgerEntry) -> None:
        self._client.table(self._LEDGER_TABLE).insert(
            {
                "entry_id": entry.entry_id,
                "wallet_id": entry.wallet_id,
                "owner_key": entry.owner_key,
                "entry_type": entry.entry_type,
                "units": entry.units,
                "balance_after": entry.balance_after,
                "created_at": entry.created_at.isoformat(),
                "purchase_id": entry.purchase_id,
                "checkout_session_id": entry.checkout_session_id,
                "event_id": entry.event_id,
                "metadata": dict(entry.metadata),
            }
        ).execute()

    def credit_units_once(self, entry: RegistryUnitLedgerEntry) -> None:
        rpc = getattr(self._client, "rpc", None)
        if not callable(rpc):
            raise RuntimeError("unit_wallet: Supabase client does not support atomic wallet credits")
        result = rpc(
            "credit_unit_wallet_once",
            {
                "p_wallet_id": entry.wallet_id,
                "p_owner_key": entry.owner_key,
                "p_entry_id": entry.entry_id,
                "p_units": entry.units,
                "p_purchase_id": entry.purchase_id,
                "p_checkout_session_id": entry.checkout_session_id,
                "p_event_id": entry.event_id,
                "p_metadata": entry.metadata,
                "p_created_at": entry.created_at.isoformat(),
            },
        )
        rows = result if isinstance(result, list) else []
        if not rows or not isinstance(rows[0], dict) or not rows[0].get("wallet_id"):
            raise RuntimeError("unit_wallet: atomic Supabase wallet credit returned no wallet record")

    def record_payment_refund_marker(
        self,
        *,
        payment_intent: str,
        charge_id: str | None,
        amount_refunded: int,
        reason: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        rpc = getattr(self._client, "rpc", None)
        if not callable(rpc):
            raise RuntimeError("unit_wallet: Supabase client does not support durable refund markers")
        rpc(
            "record_stripe_payment_refund",
            {
                "p_payment_intent": payment_intent,
                "p_charge_id": charge_id,
                "p_amount_refunded": amount_refunded,
                "p_refund_reason": reason,
                "p_refunded_at": datetime.now(UTC).isoformat(),
                "p_metadata": metadata or {},
            },
        )

    def has_payment_refund_marker(self, payment_intent: str) -> bool:
        result = self._client.table("stripe_payment_refund_markers").select("payment_intent").eq("payment_intent", payment_intent).limit(1).execute()
        return bool(result.data)

    def fetch_ledger_entries(
        self,
        owner_key: str | None = None,
        limit: int = 100,
        checkout_session_id: str | None = None,
    ) -> list[RegistryUnitLedgerEntry]:
        safe_limit = max(1, min(int(limit), 500))
        query = self._client.table(self._LEDGER_TABLE).select("*").order("created_at", desc=True).limit(safe_limit)
        if owner_key is not None:
            query = query.eq("owner_key", owner_key)
        if checkout_session_id is not None:
            query = query.eq("checkout_session_id", checkout_session_id)
        result = query.execute()
        entries: list[RegistryUnitLedgerEntry] = []
        for row in result.data or []:
            metadata = row.get("metadata") or {}
            if not isinstance(metadata, dict):
                metadata = {}
            entries.append(
                RegistryUnitLedgerEntry(
                    entry_id=row["entry_id"],
                    wallet_id=row["wallet_id"],
                    owner_key=row["owner_key"],
                    entry_type=row["entry_type"],
                    units=row["units"],
                    balance_after=row["balance_after"],
                    created_at=datetime.fromisoformat(row["created_at"]),
                    purchase_id=row.get("purchase_id") or metadata.get("purchase_id"),
                    checkout_session_id=row.get("checkout_session_id") or metadata.get("checkout_session_id"),
                    event_id=row.get("event_id") or metadata.get("event_id"),
                    metadata=metadata,
                )
            )
        return list(reversed(entries))

    def fetch_ledger_entry_by_event_id(self, event_id: str) -> RegistryUnitLedgerEntry | None:
        result = self._client.table(self._LEDGER_TABLE).select("*").eq("event_id", event_id).limit(1).execute()
        if not result.data:
            return None
        row = result.data[0]
        metadata = row.get("metadata") or {}
        if not isinstance(metadata, dict):
            metadata = {}
        return RegistryUnitLedgerEntry(
            entry_id=row["entry_id"],
            wallet_id=row["wallet_id"],
            owner_key=row["owner_key"],
            entry_type=row["entry_type"],
            units=row["units"],
            balance_after=row["balance_after"],
            created_at=datetime.fromisoformat(row["created_at"]),
            purchase_id=row.get("purchase_id") or metadata.get("purchase_id"),
            checkout_session_id=row.get("checkout_session_id") or metadata.get("checkout_session_id"),
            event_id=row.get("event_id") or metadata.get("event_id"),
            metadata=metadata,
        )


class MemoryUnitWalletRepository:
    def __init__(self) -> None:
        self._wallets: dict[str, RegistryUnitWallet] = {}
        self._wallets_by_owner: dict[str, str] = {}
        self._ledger: list[RegistryUnitLedgerEntry] = []
        self._refund_markers: set[str] = set()
        self._lock = Lock()

    def upsert_wallet(self, wallet: RegistryUnitWallet) -> None:
        with self._lock:
            self._wallets[wallet.wallet_id] = wallet
            self._wallets_by_owner[wallet.owner_key] = wallet.wallet_id

    def fetch_wallet(self, owner_key: str) -> RegistryUnitWallet | None:
        with self._lock:
            wallet_id = self._wallets_by_owner.get(owner_key)
            if wallet_id is None:
                return None
            return self._wallets[wallet_id]

    def append_ledger_entry(self, entry: RegistryUnitLedgerEntry) -> None:
        with self._lock:
            self._ledger.append(entry)
            if len(self._ledger) > _LEDGER_MAX_SIZE:
                self._ledger = self._ledger[-_LEDGER_MAX_SIZE:]

    def fetch_ledger_entries(
        self,
        owner_key: str | None = None,
        limit: int = 100,
        checkout_session_id: str | None = None,
    ) -> list[RegistryUnitLedgerEntry]:
        safe_limit = max(1, min(int(limit), 500))
        with self._lock:
            entries = self._ledger if owner_key is None else [e for e in self._ledger if e.owner_key == owner_key]
            if checkout_session_id is not None:
                entries = [e for e in entries if e.checkout_session_id == checkout_session_id]
            return list(entries[-safe_limit:])

    def fetch_ledger_entry_by_event_id(self, event_id: str) -> RegistryUnitLedgerEntry | None:
        with self._lock:
            return next((entry for entry in self._ledger if entry.event_id == event_id), None)

    def record_payment_refund_marker(
        self,
        *,
        payment_intent: str,
        charge_id: str | None,
        amount_refunded: int,
        reason: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        del charge_id, amount_refunded, reason, metadata
        with self._lock:
            self._refund_markers.add(payment_intent)

    def has_payment_refund_marker(self, payment_intent: str) -> bool:
        with self._lock:
            return payment_intent in self._refund_markers


def _make_repo() -> SupabaseUnitWalletRepository | MemoryUnitWalletRepository:
    persistence_mode = os.environ.get("IRONCLAW_PERSISTENCE_MODE", "").strip().lower()
    environment_name = (os.environ.get("IRONCLAW_ENV") or os.environ.get("APP_ENV") or os.environ.get("ENVIRONMENT", "")).strip().lower()
    durable_storage_required = _durable_storage_required()

    if persistence_mode in {"", "auto"}:
        if environment_name == "test":
            logger.info(
                "unit_wallet: persistence mode=%r environment=%r — using MemoryUnitWalletRepository",
                persistence_mode,
                environment_name,
            )
            return MemoryUnitWalletRepository()
        persistence_mode = "supabase"

    if persistence_mode in {"memory", "test"}:
        if durable_storage_required:
            raise RuntimeError("unit_wallet: durable Supabase storage is required in production")
        logger.info(
            "unit_wallet: persistence mode=%r environment=%r — using MemoryUnitWalletRepository",
            persistence_mode,
            environment_name,
        )
        return MemoryUnitWalletRepository()

    try:
        import app.supabaseclient as supabaseclient

        checker = getattr(supabaseclient, "is_supabase_configured", None)
        if persistence_mode == "supabase":
            if checker is None or not checker():
                if durable_storage_required:
                    raise RuntimeError("unit_wallet: production requires configured Supabase wallet storage")
                logger.info("unit_wallet: explicit Supabase mode selected but Supabase is not configured — using MemoryUnitWalletRepository")
                return MemoryUnitWalletRepository()
            try:
                repo = SupabaseUnitWalletRepository()
            except Exception:
                logger.warning(
                    "unit_wallet: explicit Supabase mode hit a stale/invalid singleton; resetting and retrying once before fallback",
                    exc_info=True,
                )
                if hasattr(supabaseclient, "reset_supabase_client"):
                    supabaseclient.reset_supabase_client()
                try:
                    repo = SupabaseUnitWalletRepository()
                except Exception as exc:
                    logger.exception(
                        "unit_wallet: Supabase initialized with a configured backend but failed validation; falling back to MemoryUnitWalletRepository",
                    )
                    if durable_storage_required:
                        raise RuntimeError("unit_wallet: production Supabase wallet storage failed validation") from exc
                    return MemoryUnitWalletRepository()
            logger.info("unit_wallet: SupabaseUnitWalletRepository initialized in explicit supabase mode")
            return repo

        if checker is None or not checker():
            if durable_storage_required:
                raise RuntimeError("unit_wallet: production requires configured Supabase wallet storage")
            logger.info("unit_wallet: Supabase not configured — using MemoryUnitWalletRepository")
            return MemoryUnitWalletRepository()

        try:
            repo = SupabaseUnitWalletRepository()
        except Exception:
            logger.warning(
                "unit_wallet: Supabase backend was configured but a stale singleton was detected; resetting and retrying once",
                exc_info=True,
            )
            if hasattr(supabaseclient, "reset_supabase_client"):
                supabaseclient.reset_supabase_client()
            try:
                repo = SupabaseUnitWalletRepository()
            except Exception as exc:
                logger.exception(
                    "unit_wallet: Supabase initialized with a configured backend but failed validation; falling back to MemoryUnitWalletRepository",
                )
                if durable_storage_required:
                    raise RuntimeError("unit_wallet: production Supabase wallet storage failed validation") from exc
                return MemoryUnitWalletRepository()

        logger.info("unit_wallet: SupabaseUnitWalletRepository initialized")
        return repo

    except Exception as exc:
        logger.exception(
            "unit_wallet: Supabase initialized with a configured backend but failed validation; falling back to MemoryUnitWalletRepository",
        )
        if durable_storage_required:
            raise RuntimeError("unit_wallet: production Supabase wallet storage is unavailable") from exc
        return MemoryUnitWalletRepository()


class UnitWalletRegistry:
    def __init__(self) -> None:
        self._lock = Lock()
        self._wallets: dict[str, RegistryUnitWallet] = {}
        self._wallets_by_owner: dict[str, str] = {}
        self._repo: SupabaseUnitWalletRepository | MemoryUnitWalletRepository = _make_repo()

    def _assert_durable_storage(self) -> None:
        if _durable_storage_required() and not isinstance(self._repo, SupabaseUnitWalletRepository):
            raise RuntimeError("unit_wallet: Supabase persistence is required; refusing to change unit balances in memory without durable storage")

    @staticmethod
    def _is_real_wallet(wallet: Any) -> bool:
        if not isinstance(wallet, RegistryUnitWallet):
            return False
        return bool(wallet.wallet_id) and bool(wallet.owner_key)

    def _evict_cache_if_needed(self) -> None:
        if len(self._wallets_by_owner) > _WALLET_CACHE_MAX:
            evict_count = _WALLET_CACHE_MAX // 2
            evict_owners = list(self._wallets_by_owner.keys())[:evict_count]
            for owner in evict_owners:
                wid = self._wallets_by_owner.pop(owner, None)
                if wid is not None:
                    self._wallets.pop(wid, None)

    def get_or_create_wallet(
        self,
        owner_key: str,
        metadata: dict[str, Any] | None = None,
    ) -> RegistryUnitWallet:
        normalized_owner = _normalize_owner_key(owner_key)

        with self._lock:
            wallet_id = self._wallets_by_owner.get(normalized_owner)
            if wallet_id is not None:
                cached_wallet = self._wallets.get(wallet_id)
                if cached_wallet is not None:
                    if isinstance(cached_wallet, RegistryUnitWallet) and self._is_real_wallet(cached_wallet):
                        return cached_wallet
                    self._wallets_by_owner.pop(normalized_owner, None)

        existing = self._repo.fetch_wallet(normalized_owner)
        if existing is not None:
            if not self._is_real_wallet(existing):
                raise ValueError(f"Repository returned an invalid wallet object for owner_key={normalized_owner!r}")
            with self._lock:
                self._wallets[existing.wallet_id] = existing
                self._wallets_by_owner[normalized_owner] = existing.wallet_id
                self._evict_cache_if_needed()
            return existing

        with self._lock:
            wallet_id = self._wallets_by_owner.get(normalized_owner)
            if wallet_id is not None:
                wallet = self._wallets.get(wallet_id)
                if isinstance(wallet, RegistryUnitWallet) and self._is_real_wallet(wallet):
                    return wallet

            new_wallet_id = f"wallet_{uuid.uuid4().hex}"
            wallet = RegistryUnitWallet(
                wallet_id=new_wallet_id,
                owner_key=normalized_owner,
                metadata=metadata or {},
            )
            self._wallets[new_wallet_id] = wallet
            self._wallets_by_owner[normalized_owner] = new_wallet_id
            self._evict_cache_if_needed()

        self._repo.upsert_wallet(wallet)
        return wallet

    @staticmethod
    def _normalize_ledger_metadata(metadata: dict[str, Any] | None) -> tuple[dict[str, Any], str | None, str | None, str | None]:
        payload = dict(metadata or {})
        purchase_id = str(payload.get("purchase_id") or payload.get("purchase_reference") or "").strip() or None
        checkout_session_id = str(payload.get("checkout_session_id") or payload.get("session_id") or "").strip() or None
        event_id = str(payload.get("event_id") or payload.get("ledger_event_id") or "").strip() or None
        if purchase_id:
            payload.setdefault("purchase_id", purchase_id)
        if checkout_session_id:
            payload.setdefault("checkout_session_id", checkout_session_id)
        if event_id:
            payload.setdefault("event_id", event_id)
        return payload, purchase_id, checkout_session_id, event_id

    def mark_payment_refunded(
        self,
        payment_intent: str,
        *,
        charge_id: str | None = None,
        amount_refunded: int,
        reason: str = "charge_refunded",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        normalized_payment_intent = str(payment_intent or "").strip()
        if not re.fullmatch(r"pi_[A-Za-z0-9_]+", normalized_payment_intent):
            raise ValueError("payment_intent must be a valid Stripe PaymentIntent ID")
        safe_amount = int(amount_refunded)
        if safe_amount <= 0:
            raise ValueError("amount_refunded must be greater than zero")
        self._assert_durable_storage()
        with self._lock:
            self._repo.record_payment_refund_marker(
                payment_intent=normalized_payment_intent,
                charge_id=str(charge_id or "").strip() or None,
                amount_refunded=safe_amount,
                reason=str(reason or "charge_refunded").strip(),
                metadata=metadata,
            )

    def is_payment_refunded(self, payment_intent: str) -> bool:
        normalized_payment_intent = str(payment_intent or "").strip()
        if not re.fullmatch(r"pi_[A-Za-z0-9_]+", normalized_payment_intent):
            raise ValueError("payment_intent must be a valid Stripe PaymentIntent ID")
        self._assert_durable_storage()
        return self._repo.has_payment_refund_marker(normalized_payment_intent)

    def _find_existing_event(
        self,
        *,
        event_id: str | None,
        owner_key: str,
        entry_type: str,
        key_id: str | None = None,
        event_name: str | None = None,
    ) -> RegistryUnitLedgerEntry | None:
        if not event_id:
            return None
        fetch_entry = getattr(self._repo, "fetch_ledger_entry_by_event_id", None)
        if not callable(fetch_entry):
            return None
        entry = fetch_entry(event_id)
        if entry is None:
            return None
        if entry.owner_key != _normalize_owner_key(owner_key) or entry.entry_type != entry_type:
            raise ValueError("event_id is already associated with a different wallet operation")
        if key_id is not None and str(entry.metadata.get("key_id") or "") != key_id:
            raise ValueError("event_id is already associated with a different install key")
        if event_name is not None and str(entry.metadata.get("event_type") or "") != event_name:
            raise ValueError("event_id is already associated with a different install-key event")
        return entry

    def credit_units(
        self,
        owner_key: str,
        units: int,
        metadata: dict[str, Any] | None = None,
    ) -> RegistryUnitWallet:
        self._assert_durable_storage()
        safe_units = max(0, int(units))
        wallet = self.get_or_create_wallet(owner_key=owner_key)
        normalized_metadata, purchase_id, checkout_session_id, event_id = self._normalize_ledger_metadata(metadata)

        if isinstance(self._repo, SupabaseUnitWalletRepository):
            entry = RegistryUnitLedgerEntry(
                entry_id=f"ledger_{uuid.uuid4().hex}",
                wallet_id=wallet.wallet_id,
                owner_key=wallet.owner_key,
                entry_type="credit",
                units=safe_units,
                balance_after=wallet.balance_units + safe_units,
                purchase_id=purchase_id,
                checkout_session_id=checkout_session_id,
                event_id=event_id,
                metadata=normalized_metadata,
            )
            self._repo.credit_units_once(entry)
            updated_wallet = self._repo.fetch_wallet(wallet.owner_key)
            if updated_wallet is None:
                raise RuntimeError("unit_wallet: wallet disappeared after atomic Supabase credit")
            with self._lock:
                self._wallets[updated_wallet.wallet_id] = updated_wallet
                self._wallets_by_owner[updated_wallet.owner_key] = updated_wallet.wallet_id
                self._evict_cache_if_needed()
            return updated_wallet

        with self._lock:
            payment_intent = str(normalized_metadata.get("payment_intent") or "").strip()
            if payment_intent and isinstance(self._repo, MemoryUnitWalletRepository) and self._repo.has_payment_refund_marker(payment_intent):
                raise ValueError("payment has been refunded; wallet credit was rejected")
            existing_entry = self._find_existing_event(
                event_id=event_id,
                owner_key=wallet.owner_key,
                entry_type="credit",
            )
            if existing_entry is not None:
                return wallet

            wallet.balance_units += safe_units
            wallet.total_purchased_units += safe_units
            wallet.updated_at = datetime.now(UTC)

            entry = RegistryUnitLedgerEntry(
                entry_id=f"ledger_{uuid.uuid4().hex}",
                wallet_id=wallet.wallet_id,
                owner_key=wallet.owner_key,
                entry_type="credit",
                units=safe_units,
                balance_after=wallet.balance_units,
                purchase_id=purchase_id,
                checkout_session_id=checkout_session_id,
                event_id=event_id,
                metadata=normalized_metadata,
            )

        self._repo.upsert_wallet(wallet)
        self._repo.append_ledger_entry(entry)
        return wallet

    def credit(
        self,
        owner_key: str,
        units: int,
        metadata: dict[str, Any] | None = None,
    ) -> RegistryUnitWallet:
        return self.credit_units(owner_key=owner_key, units=units, metadata=metadata)

    def debit_units(
        self,
        owner_key: str,
        units: int,
        metadata: dict[str, Any] | None = None,
    ) -> RegistryUnitWallet:
        self._assert_durable_storage()
        safe_units = max(0, int(units))
        wallet = self.get_or_create_wallet(owner_key=owner_key)
        normalized_metadata, purchase_id, checkout_session_id, event_id = self._normalize_ledger_metadata(metadata)

        insufficient: InsufficientUnitsError | None = None
        entry: RegistryUnitLedgerEntry | None = None

        with self._lock:
            existing_entry = self._find_existing_event(
                event_id=event_id,
                owner_key=wallet.owner_key,
                entry_type="debit",
            )
            if existing_entry is not None:
                return wallet

            if safe_units > wallet.balance_units:
                insufficient = InsufficientUnitsError(
                    "Insufficient protection units",
                    have=wallet.balance_units,
                    need=safe_units,
                    owner_key=wallet.owner_key,
                )
            else:
                wallet.balance_units -= safe_units
                wallet.total_consumed_units += safe_units
                wallet.updated_at = datetime.now(UTC)

                entry = RegistryUnitLedgerEntry(
                    entry_id=f"ledger_{uuid.uuid4().hex}",
                    wallet_id=wallet.wallet_id,
                    owner_key=wallet.owner_key,
                    entry_type="debit",
                    units=safe_units,
                    balance_after=wallet.balance_units,
                    purchase_id=purchase_id,
                    checkout_session_id=checkout_session_id,
                    event_id=event_id,
                    metadata=normalized_metadata,
                )

        if insufficient is not None:
            raise insufficient

        self._repo.upsert_wallet(wallet)
        self._repo.append_ledger_entry(entry)  # type: ignore[arg-type]
        return wallet

    def debit_units_for_tokens(
        self,
        owner_key: str,
        token_count: int,
        metadata: dict[str, Any] | None = None,
    ) -> tuple[RegistryUnitWallet, int]:
        required = units_required_for_tokens(token_count)
        combined_metadata = {
            "token_count": token_count,
            "tokens_per_unit": TOKEN_CHUNK_SIZE,
            "units_required": required,
            **(metadata or {}),
        }
        wallet = self.debit_units(
            owner_key=owner_key,
            units=required,
            metadata=combined_metadata,
        )
        return wallet, required

    def debit_units_for_install_key(
        self,
        owner_key: str,
        key_id: str,
        program: str,
        units: int,
        *,
        payment_id: str | None = None,
        action_type: str = "prompt",
        metadata: dict[str, Any] | None = None,
    ) -> tuple[RegistryUnitWallet, InstallKeyUsageSource, InstallKeyUsageLedgerEntry]:
        if not key_id:
            raise ValueError("key_id is required")
        if not program:
            raise ValueError("program is required")
        if _is_generic_platform_credential(owner_key):
            raise ValueError("owner_key must be a customer or org identity, not a generic platform API key")
        if _is_generic_platform_credential(str(key_id)):
            raise ValueError("key_id must be an install key identity, not a generic platform API credential")
        safe_units = max(0, int(units))

        payload = dict(metadata or {})
        explicit_owner = str(payload.get("owner_key") or "").strip().lower()
        if explicit_owner and explicit_owner != _normalize_owner_key(owner_key):
            raise ValueError("metadata owner_key does not match the wallet owner_key for install-key usage")
        explicit_key = str(payload.get("key_id") or "").strip()
        if explicit_key and explicit_key != str(key_id):
            raise ValueError("metadata key_id does not match the install key being debited")
        event_id = str(payload.get("event_id") or payload.get("ledger_event_id") or "").strip() or None

        wallet = self.get_or_create_wallet(owner_key=owner_key)

        with self._lock:
            existing_entry = self._find_existing_event(
                event_id=event_id,
                owner_key=wallet.owner_key,
                entry_type="install_key_debit",
                key_id=key_id,
                event_name=str(payload.get("event_type") or "").strip() or None,
            )
            if existing_entry is not None:
                usage = wallet.install_key_usage.get(key_id)
                if usage is None:
                    raise RuntimeError("install-key debit ledger exists without its wallet usage summary")
                return (
                    wallet,
                    usage,
                    InstallKeyUsageLedgerEntry(
                        entry_id=existing_entry.entry_id,
                        owner_key=existing_entry.owner_key,
                        key_id=key_id,
                        program=program,
                        action_type=str(existing_entry.metadata.get("action_type") or action_type),
                        units=existing_entry.units,
                        balance_after=existing_entry.balance_after,
                        payment_id=existing_entry.purchase_id,
                        created_at=existing_entry.created_at,
                        metadata=dict(existing_entry.metadata),
                    ),
                )

            if safe_units > wallet.balance_units:
                raise InsufficientUnitsError(
                    "Insufficient protection units",
                    have=wallet.balance_units,
                    need=safe_units,
                    owner_key=wallet.owner_key,
                )

            wallet.balance_units -= safe_units
            wallet.total_consumed_units += safe_units
            wallet.updated_at = datetime.now(UTC)

            usage = wallet.install_key_usage.setdefault(
                key_id,
                InstallKeyUsageSource(
                    key_id=key_id,
                    owner_key=wallet.owner_key,
                    program=program,
                ),
            )
            if usage.owner_key != wallet.owner_key:
                raise ValueError("install-key usage for a different owner_key is not allowed on this wallet")
            usage.program = program
            usage.balance_units = max(wallet.balance_units, 0)
            usage.metadata.update(
                {
                    **payload,
                    "owner_key": wallet.owner_key,
                    "key_id": key_id,
                    "program": program,
                    "payment_id": payment_id,
                    "action_type": action_type,
                }
            )

            usage.register_usage_event(
                units=safe_units,
                occurred_at=wallet.updated_at,
            )

            canonical_metadata = {
                **payload,
                "owner_key": wallet.owner_key,
                "key_id": key_id,
                "program": program,
                "payment_id": payment_id,
                "action_type": action_type,
            }

            entry = InstallKeyUsageLedgerEntry(
                entry_id=f"ledger_{uuid.uuid4().hex}",
                owner_key=wallet.owner_key,
                key_id=key_id,
                program=program,
                action_type=action_type,
                units=safe_units,
                balance_after=wallet.balance_units,
                payment_id=payment_id,
                created_at=wallet.updated_at,
                metadata=canonical_metadata,
            )

            ledger_entry = RegistryUnitLedgerEntry(
                entry_id=entry.entry_id,
                wallet_id=wallet.wallet_id,
                owner_key=wallet.owner_key,
                entry_type="install_key_debit",
                units=safe_units,
                balance_after=wallet.balance_units,
                created_at=wallet.updated_at,
                purchase_id=payment_id or payload.get("purchase_id"),
                checkout_session_id=payload.get("checkout_session_id") or payload.get("session_id"),
                event_id=event_id or f"install_key_debit:{key_id}:{wallet.updated_at.isoformat()}",
                metadata=entry.as_dict(),
            )

        self._repo.upsert_wallet(wallet)
        self._repo.append_ledger_entry(ledger_entry)
        return wallet, usage, entry

    def record_install_key_event(
        self,
        owner_key: str,
        *,
        key_id: str | None,
        program: str | None,
        event_type: str,
        units: int = 0,
        action_type: str | None = None,
        occurred_at: datetime | str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> bool:
        wallet = self.get_or_create_wallet(owner_key)
        effective_program = (program or "openclaw").strip() or "openclaw"
        event_metadata = dict(metadata or {})
        event_id = str(event_metadata.get("event_id") or event_metadata.get("ledger_event_id") or "").strip() or None

        if isinstance(occurred_at, datetime):
            timestamp = occurred_at.astimezone(UTC) if occurred_at.tzinfo is not None else occurred_at.replace(tzinfo=UTC)
        elif isinstance(occurred_at, str):
            candidate = occurred_at.strip()
            if candidate.endswith("Z"):
                candidate = candidate[:-1] + "+00:00"
            timestamp = datetime.fromisoformat(candidate)
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=UTC)
            timestamp = timestamp.astimezone(UTC)
        else:
            timestamp = datetime.now(UTC)

        entry: RegistryUnitLedgerEntry | None = None
        with self._lock:
            existing_entry = self._find_existing_event(
                event_id=event_id,
                owner_key=wallet.owner_key,
                entry_type="install_key_event",
                key_id=key_id,
                event_name=event_type,
            )
            if existing_entry is not None:
                return False

            if key_id:
                usage = wallet.install_key_usage.setdefault(
                    key_id,
                    InstallKeyUsageSource(
                        key_id=key_id,
                        owner_key=wallet.owner_key,
                        program=effective_program,
                    ),
                )
                usage.program = effective_program
                usage.balance_units = max(wallet.balance_units, 0)
                usage.last_action_at = timestamp
                usage.metadata.update(
                    {
                        "owner_key": wallet.owner_key,
                        "key_id": key_id,
                        "program": effective_program,
                        "last_event_type": event_type,
                        "last_event_at": timestamp.isoformat().replace("+00:00", "Z"),
                        "action_type": action_type or usage.metadata.get("action_type") or "telemetry",
                    }
                )
                if units > 0 and event_type not in {"usage_units_debited"}:
                    usage.total_consumed_units += int(units)
                wallet.install_key_usage[key_id] = usage

            wallet.updated_at = timestamp
            wallet.metadata.setdefault("dashboard_sync", {})
            wallet.metadata["dashboard_sync"][event_type] = {
                "occurred_at": timestamp.isoformat().replace("+00:00", "Z"),
                "key_id": key_id,
                "owner_key": wallet.owner_key,
                "program": effective_program,
                "units": int(units),
                "event_id": event_id,
                "metadata": event_metadata,
            }

            if key_id:
                event_metadata = {
                    "event_type": event_type,
                    "key_id": key_id,
                    "program": effective_program,
                    "owner_key": wallet.owner_key,
                    "action_type": action_type,
                    **event_metadata,
                }
                purchase_id = str(event_metadata.get("purchase_id") or event_metadata.get("purchase_reference") or "").strip() or None
                checkout_session_id = str(event_metadata.get("checkout_session_id") or event_metadata.get("session_id") or "").strip() or None
                event_id = str(event_metadata.get("event_id") or f"{event_type}:{key_id}:{int(timestamp.timestamp() * 1000)}").strip() or None
                entry = RegistryUnitLedgerEntry(
                    entry_id=f"ledger_{event_type}_{key_id}_{int(timestamp.timestamp() * 1000)}",
                    wallet_id=wallet.wallet_id,
                    owner_key=wallet.owner_key,
                    entry_type="install_key_event",
                    units=int(units),
                    balance_after=wallet.balance_units,
                    created_at=timestamp,
                    purchase_id=purchase_id,
                    checkout_session_id=checkout_session_id,
                    event_id=event_id,
                    metadata=event_metadata,
                )

        self._repo.upsert_wallet(wallet)
        if entry is not None:
            self._repo.append_ledger_entry(entry)
        return True

    def refund_units(
        self,
        owner_key: str,
        units: int,
        metadata: dict[str, Any] | None = None,
    ) -> RegistryUnitWallet:
        safe_units = max(0, int(units))
        wallet = self.get_or_create_wallet(owner_key=owner_key)
        normalized_metadata, purchase_id, checkout_session_id, event_id = self._normalize_ledger_metadata(metadata)

        with self._lock:
            wallet.balance_units += safe_units
            wallet.total_refunded_units += safe_units
            wallet.updated_at = datetime.now(UTC)

            entry = RegistryUnitLedgerEntry(
                entry_id=f"ledger_{uuid.uuid4().hex}",
                wallet_id=wallet.wallet_id,
                owner_key=wallet.owner_key,
                entry_type="refund",
                units=safe_units,
                balance_after=wallet.balance_units,
                purchase_id=purchase_id,
                checkout_session_id=checkout_session_id,
                event_id=event_id,
                metadata=normalized_metadata,
            )

        self._repo.upsert_wallet(wallet)
        self._repo.append_ledger_entry(entry)
        return wallet

    def get_wallet(self, owner_key: str) -> RegistryUnitWallet | None:
        normalized_owner = _normalize_owner_key(owner_key)
        with self._lock:
            wallet_id = self._wallets_by_owner.get(normalized_owner)
            if wallet_id is not None:
                cached_wallet = self._wallets.get(wallet_id)
                if cached_wallet is not None:
                    if isinstance(cached_wallet, RegistryUnitWallet) and self._is_real_wallet(cached_wallet):
                        return cached_wallet
                    self._wallets_by_owner.pop(normalized_owner, None)

        wallet = self._repo.fetch_wallet(normalized_owner)
        if wallet is None:
            return None
        if not self._is_real_wallet(wallet):
            raise ValueError(f"Repository returned invalid wallet for owner_key={normalized_owner!r}")

        with self._lock:
            self._wallets[wallet.wallet_id] = wallet
            self._wallets_by_owner[normalized_owner] = wallet.wallet_id
            self._evict_cache_if_needed()
        return wallet

    def list_ledger_entries(
        self,
        owner_key: str | None = None,
        limit: int = 100,
        checkout_session_id: str | None = None,
    ) -> list[RegistryUnitLedgerEntry]:
        return self._repo.fetch_ledger_entries(owner_key=owner_key, limit=limit, checkout_session_id=checkout_session_id)

    def revoke_purchase_units(self, owner_key: str, purchase_reference: str, units: int, reason: str = "refund") -> int:
        reference_value = str(purchase_reference or "").strip()
        safe_units = max(0, int(units))
        if not reference_value or safe_units <= 0:
            return 0
        normalized_owner = _normalize_owner_key(owner_key)
        # Idempotency: one revocation per purchase, keyed by a deterministic event_id.
        event_id = f"refund_revoke:{reference_value}"
        wallet = self.get_or_create_wallet(owner_key=normalized_owner)
        normalized_metadata, purchase_id, checkout_session_id, _ = self._normalize_ledger_metadata(
            {
                "purchase_reference": reference_value,
                "checkout_session_id": reference_value,
                "event_id": event_id,
                "reason": reason,
                "requested_units": safe_units,
            }
        )

        entry: RegistryUnitLedgerEntry | None = None
        with self._lock:
            if self._find_existing_event(event_id=event_id, owner_key=wallet.owner_key, entry_type="refund_revoke") is not None:
                return 0

            amount = min(safe_units, wallet.balance_units)
            if amount <= 0:
                return 0

            wallet.balance_units -= amount
            wallet.updated_at = datetime.now(UTC)
            entry = RegistryUnitLedgerEntry(
                entry_id=f"ledger_{uuid.uuid4().hex}",
                wallet_id=wallet.wallet_id,
                owner_key=wallet.owner_key,
                entry_type="refund_revoke",
                units=amount,
                balance_after=wallet.balance_units,
                purchase_id=purchase_id,
                checkout_session_id=checkout_session_id,
                event_id=event_id,
                metadata=normalized_metadata,
            )

        self._repo.upsert_wallet(wallet)
        self._repo.append_ledger_entry(entry)  # type: ignore[arg-type]
        return amount

    def revoke_units_for_checkout(self, owner_key: str, checkout_session_id: str, reason: str = "refund") -> int:
        session_value = str(checkout_session_id or "").strip()
        if not session_value:
            return 0
        normalized_owner = _normalize_owner_key(owner_key)
        granted = sum(entry.units for entry in self.list_ledger_entries(owner_key=normalized_owner, limit=1000, checkout_session_id=session_value) if entry.entry_type == "credit")
        return self.revoke_purchase_units(normalized_owner, session_value, granted, reason=reason)

    def revoke_units_for_refund(
        self,
        owner_keys: list[str],
        *,
        payment_intent: str | None = None,
        invoice_id: str | None = None,
        checkout_session_id: str | None = None,
        reason: str = "refund",
    ) -> dict[str, int]:
        payment_intent_value = str(payment_intent or "").strip()
        invoice_value = str(invoice_id or "").strip()
        session_value = str(checkout_session_id or "").strip()
        if not payment_intent_value and not invoice_value and not session_value:
            return {}
        revoked: dict[str, int] = {}
        for owner in sorted({_normalize_owner_key(key) for key in owner_keys if key}):
            if self.get_wallet(owner) is None:
                continue
            granted: dict[str, int] = {}
            for entry in self.list_ledger_entries(owner_key=owner, limit=1000):
                # Checkout-session credits may carry no purchase reference, so fall back to the session id.
                reference = entry.purchase_id or entry.checkout_session_id
                if entry.entry_type != "credit" or not reference:
                    continue
                metadata = entry.metadata or {}
                matches = (bool(payment_intent_value) and metadata.get("payment_intent") == payment_intent_value) or (bool(invoice_value) and metadata.get("invoice_id") == invoice_value) or reference in {value for value in (session_value, invoice_value) if value}
                if matches:
                    granted[reference] = granted.get(reference, 0) + entry.units
            for reference, units in granted.items():
                amount = self.revoke_purchase_units(owner, reference, units, reason=reason)
                if amount:
                    revoked[reference] = revoked.get(reference, 0) + amount
        return revoked

    def get_key_usage_summary(
        self,
        owner_key: str,
        *,
        key_id: str | None = None,
    ) -> dict[str, Any]:
        wallet = self.get_wallet(owner_key)
        if wallet is None:
            owner = _normalize_owner_key(owner_key)
            return {
                "owner_key": owner,
                "wallet_balance_units": 0,
                "total_consumed_units": 0,
                "install_key_usage": {},
            }

        if key_id is not None:
            usage = wallet.install_key_usage.get(key_id)
            return {
                "owner_key": wallet.owner_key,
                "wallet_balance_units": wallet.balance_units,
                "total_consumed_units": wallet.total_consumed_units,
                "install_key_usage": {key_id: usage.as_summary()} if usage is not None else {},
            }

        return {
            "owner_key": wallet.owner_key,
            "wallet_balance_units": wallet.balance_units,
            "total_consumed_units": wallet.total_consumed_units,
            "install_key_usage": {key: value.as_summary() for key, value in sorted(wallet.install_key_usage.items())},
        }


_unit_wallet_registry = UnitWalletRegistry()


def get_unit_wallet_registry() -> UnitWalletRegistry:
    return _unit_wallet_registry
